Introduction
============

This directory contains Device Tree overlays. Device Tree makes it possible
to support many hardware configurations with a single kernel and without the
need to explicitly load or blacklist kernel modules. Note that this isn't a
"pure" Device Tree configuration (c.f. MACH_BCM2835) - some on-board devices
are still configured by the board support code, but the intention is to
eventually reach that goal.

On Raspberry Pi, Device Tree usage is controlled from /boot/config.txt. By
default, the Raspberry Pi kernel boots with device tree enabled. You can
completely disable DT usage (for now) by adding:

    device_tree=

to your config.txt, which should cause your Pi to revert to the old way of
doing things after a reboot.

In /boot you will find a .dtb for each base platform. This describes the
hardware that is part of the Raspberry Pi board. The loader (start.elf and its
siblings) selects the .dtb file appropriate for the platform by name, and reads
it into memory. At this point, all of the optional interfaces (i2c, i2s, spi)
are disabled, but they can be enabled using Device Tree parameters:

    dtparam=i2c=on,i2s=on,spi=on

However, this shouldn't be necessary in many use cases because loading an
overlay that requires one of those interfaces will cause it to be enabled
automatically, and it is advisable to only enable interfaces if they are
needed.

Configuring additional, optional hardware is done using Device Tree overlays
(see below).

GPIO numbering uses the hardware pin numbering scheme (aka BCM scheme) and
not the physical pin numbers.

raspi-config
============

The Advanced Options section of the raspi-config utility can enable and disable
Device Tree use, as well as toggling the I2C and SPI interfaces. Note that it
is possible to both enable an interface and blacklist the driver, if for some
reason you should want to defer the loading.

Modules
=======

As well as describing the hardware, Device Tree also gives enough information
to allow suitable driver modules to be located and loaded, with the corollary
that unneeded modules are not loaded. As a result it should be possible to
remove lines from /etc/modules, and /etc/modprobe.d/raspi-blacklist.conf can
have its contents deleted (or commented out).

Using Overlays
==============

Overlays are loaded using the "dtoverlay" config.txt setting. As an example,
consider I2C Real Time Clock drivers. In the pre-DT world these would be loaded
by writing a magic string comprising a device identifier and an I2C address to
a special file in /sys/class/i2c-adapter, having first loaded the driver for
the I2C interface and the RTC device - something like this:

    modprobe i2c-bcm2835
    modprobe rtc-ds1307
    echo ds1307 0x68 > /sys/class/i2c-adapter/i2c-1/new_device

With DT enabled, this becomes a line in config.txt:

    dtoverlay=i2c-rtc,ds1307

This causes the file /boot/overlays/i2c-rtc.dtbo to be loaded and a "node"
describing the DS1307 I2C device to be added to the Device Tree for the Pi. By
default it usees address 0x68, but this can be modified with an additional DT
parameter:

    dtoverlay=i2c-rtc,ds1307,addr=0x68

Parameters usually have default values, although certain parameters are
mandatory. See the list of overlays below for a description of the parameters
and their defaults.

The Overlay and Parameter Reference
===================================

N.B. When editing this file, please preserve the indentation levels to make it
simple to parse programmatically. NO HARD TABS.


Name:   <The base DTB>
Info:   Configures the base Raspberry Pi hardware
Load:   <loaded automatically>
Params:
        audio                   Set to "on" to enable the onboard ALSA audio
                                interface (default "off")

        axiperf                 Set to "on" to enable the AXI bus performance
                                monitors.
                                See /sys/kernel/debug/raspberrypi_axi_monitor
                                for the results.

        eee                     Enable Energy Efficient Ethernet support for
                                compatible devices (default "on"). See also
                                "tx_lpi_timer". Pi3B+ only.

        eth_downshift_after     Set the number of auto-negotiation failures
                                after which the 1000Mbps modes are disabled.
                                Legal values are 2, 3, 4, 5 and 0, where
                                0 means never downshift (default 2). Pi3B+ only.

        eth_led0                Set mode of LED0 - amber on Pi3B+ (default "1"),
                                green on Pi4 (default "0").
                                The legal values are:

                                Pi3B+

                                0=link/activity          1=link1000/activity
                                2=link100/activity       3=link10/activity
                                4=link100/1000/activity  5=link10/1000/activity
                                6=link10/100/activity    14=off    15=on

                                Pi4

                                0=Speed/Activity         1=Speed
                                2=Flash activity         3=FDX
                                4=Off                    5=On
                                6=Alt                    7=Speed/Flash
                                8=Link                   9=Activity

        eth_led1                Set mode of LED1 - green on Pi3B (default "6"),
                                amber on Pi4 (default "8"). See eth_led0 for
                                legal values.

        eth_max_speed           Set the maximum speed a link is allowed
                                to negotiate. Legal values are 10, 100 and
                                1000 (default 1000). Pi3B+ only.

        i2c_arm                 Set to "on" to enable the ARM's i2c interface
                                (default "off")

        i2c_vc                  Set to "on" to enable the i2c interface
                                usually reserved for the VideoCore processor
                                (default "off")

        i2c                     An alias for i2c_arm

        i2c_arm_baudrate        Set the baudrate of the ARM's i2c interface
                                (default "100000")

        i2c_vc_baudrate         Set the baudrate of the VideoCore i2c interface
                                (default "100000")

        i2c_baudrate            An alias for i2c_arm_baudrate

        i2s                     Set to "on" to enable the i2s interface
                                (default "off")

        spi                     Set to "on" to enable the spi interfaces
                                (default "off")

        spi_dma4                Use to enable 40-bit DMA on spi interfaces
                                (the assigned value doesn't matter)
                                (2711 only)

        random                  Set to "on" to enable the hardware random
                                number generator (default "on")

        sd_overclock            Clock (in MHz) to use when the MMC framework
                                requests 50MHz

        sd_poll_once            Looks for a card once after booting. Useful
                                for network booting scenarios to avoid the
                                overhead of continuous polling. N.B. Using
                                this option restricts the system to using a
                                single card per boot (or none at all).
                                (default off)

        sd_force_pio            Disable DMA support for SD driver (default off)

        sd_pio_limit            Number of blocks above which to use DMA for
                                SD card (default 1)

        sd_debug                Enable debug output from SD driver (default off)

        sdio_overclock          Clock (in MHz) to use when the MMC framework
                                requests 50MHz for the SDIO/WiFi interface.

        tx_lpi_timer            Set the delay in microseconds between going idle
                                and entering the low power state (default 600).
                                Requires EEE to be enabled - see "eee".

        uart0                   Set to "off" to disable uart0 (default "on")

        uart1                   Set to "on" or "off" to enable or disable uart1
                                (default varies)

        watchdog                Set to "on" to enable the hardware watchdog
                                (default "off")

        act_led_trigger         Choose which activity the LED tracks.
                                Use "heartbeat" for a nice load indicator.
                                (default "mmc")

        act_led_activelow       Set to "on" to invert the sense of the LED
                                (default "off")
                                N.B. For Pi 3B, 3B+, 3A+ and 4B, use the act-led
                                overlay.

        act_led_gpio            Set which GPIO to use for the activity LED
                                (in case you want to connect it to an external
                                device)
                                (default "16" on a non-Plus board, "47" on a
                                Plus or Pi 2)
                                N.B. For Pi 3B, 3B+, 3A+ and 4B, use the act-led
                                overlay.

        pwr_led_trigger
        pwr_led_activelow
        pwr_led_gpio
                                As for act_led_*, but using the PWR LED.
                                Not available on Model A/B boards.

        N.B. It is recommended to only enable those interfaces that are needed.
        Leaving all interfaces enabled can lead to unwanted behaviour (i2c_vc
        interfering with Pi Camera, I2S and SPI hogging GPIO pins, etc.)
        Note also that i2c, i2c_arm and i2c_vc are aliases for the physical
        interfaces i2c0 and i2c1. Use of the numeric variants is still possible
        but deprecated because the ARM/VC assignments differ between board
        revisions. The same board-specific mapping applies to i2c_baudrate,
        and the other i2c baudrate parameters.


Name:   act-led
Info:   Pi 3B, 3B+, 3A+ and 4B use a GPIO expander to drive the LEDs which can
        only be accessed from the VPU. There is a special driver for this with a
        separate DT node, which has the unfortunate consequence of breaking the
        act_led_gpio and act_led_activelow dtparams.
        This overlay changes the GPIO controller back to the standard one and
        restores the dtparams.
Load:   dtoverlay=act-led,<param>=<val>
Params: activelow               Set to "on" to invert the sense of the LED
                                (default "off")

        gpio                    Set which GPIO to use for the activity LED
                                (in case you want to connect it to an external
                                device)
                                REQUIRED


Name:   adau1977-adc
Info:   Overlay for activation of ADAU1977 ADC codec over I2C for control
        and I2S for data.
Load:   dtoverlay=adau1977-adc
Params: <None>


Name:   adau7002-simple
Info:   Overlay for the activation of ADAU7002 stereo PDM to I2S converter.
Load:   dtoverlay=adau7002-simple,<param>=<val>
Params: card-name               Override the default, "adau7002", card name.


Name:   ads1015
Info:   Overlay for activation of Texas Instruments ADS1015 ADC over I2C
Load:   dtoverlay=ads1015,<param>=<val>
Params: addr                    I2C bus address of device. Set based on how the
                                addr pin is wired. (default=0x48 assumes addr
                                is pulled to GND)
        cha_enable              Enable virtual channel a. (default=true)
        cha_cfg                 Set the configuration for virtual channel a.
                                (default=4 configures this channel for the
                                voltage at A0 with respect to GND)
        cha_datarate            Set the datarate (samples/sec) for this channel.
                                (default=4 sets 1600 sps)
        cha_gain                Set the gain of the Programmable Gain
                                Amplifier for this channel. (default=2 sets the
                                full scale of the channel to 2.048 Volts)

        Channel (ch) parameters can be set for each enabled channel.
        A maximum of 4 channels can be enabled (letters a thru d).
        For more information refer to the device datasheet at:
        http://www.ti.com/lit/ds/symlink/ads1015.pdf


Name:   ads1115
Info:   Texas Instruments ADS1115 ADC
Load:   dtoverlay=ads1115,<param>[=<val>]
Params: addr                    I2C bus address of device. Set based on how the
                                addr pin is wired. (default=0x48 assumes addr
                                is pulled to GND)
        cha_enable              Enable virtual channel a.
        cha_cfg                 Set the configuration for virtual channel a.
                                (default=4 configures this channel for the
                                voltage at A0 with respect to GND)
        cha_datarate            Set the datarate (samples/sec) for this channel.
                                (default=7 sets 860 sps)
        cha_gain                Set the gain of the Programmable Gain
                                Amplifier for this channel. (Default 1 sets the
                                full scale of the channel to 4.096 Volts)

        Channel parameters can be set for each enabled channel.
        A maximum of 4 channels can be enabled (letters a thru d).
        For more information refer to the device datasheet at:
        http://www.ti.com/lit/ds/symlink/ads1115.pdf


Name:   ads7846
Info:   ADS7846 Touch controller
Load:   dtoverlay=ads7846,<param>=<val>
Params: cs                      SPI bus Chip Select (default 1)
        speed                   SPI bus speed (default 2MHz, max 3.25MHz)
        penirq                  GPIO used for PENIRQ. REQUIRED
        penirq_pull             Set GPIO pull (default 0=none, 2=pullup)
        swapxy                  Swap x and y axis
        xmin                    Minimum value on the X axis (default 0)
        ymin                    Minimum value on the Y axis (default 0)
        xmax                    Maximum value on the X axis (default 4095)
        ymax                    Maximum value on the Y axis (default 4095)
        pmin                    Minimum reported pressure value (default 0)
        pmax                    Maximum reported pressure value (default 65535)
        xohms                   Touchpanel sensitivity (X-plate resistance)
                                (default 400)

        penirq is required and usually xohms (60-100) has to be set as well.
        Apart from that, pmax (255) and swapxy are also common.
        The rest of the calibration can be done with xinput-calibrator.
        See: github.com/notro/fbtft/wiki/FBTFT-on-Raspian
        Device Tree binding document:
        www.kernel.org/doc/Documentation/devicetree/bindings/input/ads7846.txt


Name:   adv7282m
Info:   Analog Devices ADV7282M analogue video to CSI2 bridge.
        Uses Unicam1, which is the standard camera connector on most Pi
        variants.
Load:   dtoverlay=adv7282m,<param>=<val>
Params: addr                    Overrides the I2C address (default 0x21)


Name:   adv728x-m
Info:   Analog Devices ADV728[0|1|2]-M analogue video to CSI2 bridges.
        This is a wrapper for adv7282m, and defaults to ADV7282M.
Load:   dtoverlay=adv728x-m,<param>=<val>
Params: addr                    Overrides the I2C address (default 0x21)
        adv7280m                Select ADV7280-M.
        adv7281m                Select ADV7281-M.
        adv7281ma               Select ADV7281-MA.


Name:   akkordion-iqdacplus
Info:   Configures the Digital Dreamtime Akkordion Music Player (based on the
        OEM IQAudIO DAC+ or DAC Zero module).
Load:   dtoverlay=akkordion-iqdacplus,<param>=<val>
Params: 24db_digital_gain       Allow gain to be applied via the PCM512x codec
                                Digital volume control. Enable with
                                dtoverlay=akkordion-iqdacplus,24db_digital_gain
                                (The default behaviour is that the Digital
                                volume control is limited to a maximum of
                                0dB. ie. it can attenuate but not provide
                                gain. For most users, this will be desired
                                as it will prevent clipping. By appending
                                the 24db_digital_gain parameter, the Digital
                                volume control will allow up to 24dB of
                                gain. If this parameter is enabled, it is the
                                responsibility of the user to ensure that
                                the Digital volume control is set to a value
                                that does not result in clipping/distortion!)


Name:   allo-boss-dac-pcm512x-audio
Info:   Configures the Allo Boss DAC audio cards.
Load:   dtoverlay=allo-boss-dac-pcm512x-audio,<param>
Params: 24db_digital_gain       Allow gain to be applied via the PCM512x codec
                                Digital volume control. Enable with
                                "dtoverlay=allo-boss-dac-pcm512x-audio,
                                24db_digital_gain"
                                (The default behaviour is that the Digital
                                volume control is limited to a maximum of
                                0dB. ie. it can attenuate but not provide
                                gain. For most users, this will be desired
                                as it will prevent clipping. By appending
                                the 24db_digital_gain parameter, the Digital
                                volume control will allow up to 24dB of
                                gain. If this parameter is enabled, it is the
                                responsibility of the user to ensure that
                                the Digital volume control is set to a value
                                that does not result in clipping/distortion!)
        slave                   Force Boss DAC into slave mode, using Pi a
                                master for bit clock and frame clock. Enable
                                with "dtoverlay=allo-boss-dac-pcm512x-audio,
                                slave"


Name:   allo-digione
Info:   Configures the Allo Digione audio card
Load:   dtoverlay=allo-digione
Params: <None>


Name:   allo-katana-dac-audio
Info:   Configures the Allo Katana DAC audio card
Load:   dtoverlay=allo-katana-dac-audio
Params: <None>


Name:   allo-piano-dac-pcm512x-audio
Info:   Configures the Allo Piano DAC (2.0/2.1) audio cards.
        (NB. This initial support is for 2.0 channel audio ONLY! ie. stereo.
        The subwoofer outputs on the Piano 2.1 are not currently supported!)
Load:   dtoverlay=allo-piano-dac-pcm512x-audio,<param>
Params: 24db_digital_gain       Allow gain to be applied via the PCM512x codec
                                Digital volume control.
                                (The default behaviour is that the Digital
                                volume control is limited to a maximum of
                                0dB. ie. it can attenuate but not provide
                                gain. For most users, this will be desired
                                as it will prevent clipping. By appending
                                the 24db_digital_gain parameter, the Digital
                                volume control will allow up to 24dB of
                                gain. If this parameter is enabled, it is the
                                responsibility of the user to ensure that
                                the Digital volume control is set to a value
                                that does not result in clipping/distortion!)


Name:   allo-piano-dac-plus-pcm512x-audio
Info:   Configures the Allo Piano DAC (2.1) audio cards.
Load:   dtoverlay=allo-piano-dac-plus-pcm512x-audio,<param>
Params: 24db_digital_gain       Allow gain to be applied via the PCM512x codec
                                Digital volume control.
                                (The default behaviour is that the Digital
                                volume control is limited to a maximum of
                                0dB. ie. it can attenuate but not provide
                                gain. For most users, this will be desired
                                as it will prevent clipping. By appending
                                the 24db_digital_gain parameter, the Digital
                                volume control will allow up to 24dB of
                                gain. If this parameter is enabled, it is the
                                responsibility of the user to ensure that
                                the Digital volume control is set to a value
                                that does not result in clipping/distortion!)
        glb_mclk                This option is only with Kali board. If enabled,
                                MCLK for Kali is used and PLL is disabled for
                                better voice quality. (default Off)


Name:   anyspi
Info:   Universal device tree overlay for SPI devices

        Just specify the SPI address and device name ("compatible" property).
        This overlay lacks any device-specific parameter support!

        For devices on spi1 or spi2, the interfaces should be enabled
        with one of the spi1-1/2/3cs and/or spi2-1/2/3cs overlays.

        Examples:
        1. SPI NOR flash on spi0.1, maximum SPI clock frequency 45MHz:
            dtoverlay=anyspi:spi0-1,dev="jedec,spi-nor",speed=45000000
        2. MCP3204 ADC on spi1.2, maximum SPI clock frequency 500kHz:
            dtoverlay=anyspi:spi1-2,dev="microchip,mcp3204"
Load:   dtoverlay=anyspi,<param>=<val>
Params: spi<n>-<m>              Configure device at spi<n>, cs<m>
                                (boolean, required)
        dev                     Set device name to search compatible module
                                (string, required)
        speed                   Set SPI clock frequency in Hz
                                (integer, optional, default 500000)


Name:   apds9960
Info:   Configures the AVAGO APDS9960 digital proximity, ambient light, RGB and
        gesture sensor
Load:   dtoverlay=apds9960,<param>=<val>
Params: gpiopin                 GPIO used for INT (default 4)
        noints                  Disable the interrupt GPIO line.


Name:   applepi-dac
Info:   Configures the Orchard Audio ApplePi-DAC audio card
Load:   dtoverlay=applepi-dac
Params: <None>


Name:   at86rf233
Info:   Configures the Atmel AT86RF233 802.15.4 low-power WPAN transceiver,
        connected to spi0.0
Load:   dtoverlay=at86rf233,<param>=<val>
Params: interrupt               GPIO used for INT (default 23)
        reset                   GPIO used for Reset (default 24)
        sleep                   GPIO used for Sleep (default 25)
        speed                   SPI bus speed in Hz (default 3000000)
        trim                    Fine tuning of the internal capacitance
                                arrays (0=+0pF, 15=+4.5pF, default 15)


Name:   audioinjector-addons
Info:   Configures the audioinjector.net audio add on soundcards
Load:   dtoverlay=audioinjector-addons,<param>=<val>
Params: non-stop-clocks         Keeps the clocks running even when the stream
                                is paused or stopped (default off)


Name:   audioinjector-isolated-soundcard
Info:   Configures the audioinjector.net isolated soundcard
Load:   dtoverlay=audioinjector-isolated-soundcard
Params: <None>


Name:   audioinjector-ultra
Info:   Configures the audioinjector.net ultra soundcard
Load:   dtoverlay=audioinjector-ultra
Params: <None>


Name:   audioinjector-wm8731-audio
Info:   Configures the audioinjector.net audio add on soundcard
Load:   dtoverlay=audioinjector-wm8731-audio
Params: <None>


Name:   audiosense-pi
Info:   Configures the audiosense-pi add on soundcard
        For more information refer to
        https://gitlab.com/kakar0t/audiosense-pi
Load:   dtoverlay=audiosense-pi
Params: <None>


Name:   audremap
Info:   Switches PWM sound output to GPIOs on the 40-pin header
Load:   dtoverlay=audremap,<param>=<val>
Params: swap_lr                 Reverse the channel allocation, which will also
                                swap the audio jack outputs (default off)
        enable_jack             Don't switch off the audio jack output
                                (default off)
        pins_12_13              Select GPIOs 12 & 13 (default)
        pins_18_19              Select GPIOs 18 & 19


Name:   balena-fin
Info:   Overlay that enables WiFi, Bluetooth and the GPIO expander on the
        balenaFin carrier board for the Raspberry Pi Compute Module 3/3+ Lite.
Load:   dtoverlay=balena-fin
Params: <None>


Name:   bmp085_i2c-sensor
Info:   This overlay is now deprecated - see i2c-sensor
Load:   <Deprecated>


Name:   cma
Info:   Set custom CMA sizes, only use if you know what you are doing, might
        clash with other overlays like vc4-fkms-v3d and vc4-kms-v3d.
Load:   dtoverlay=cma,<param>=<val>
Params: cma-256                 CMA is 256MB (needs 1GB)
        cma-192                 CMA is 192MB (needs 1GB)
        cma-128                 CMA is 128MB
        cma-96                  CMA is 96MB
        cma-64                  CMA is 64MB
        cma-size                CMA size in bytes, 4MB aligned
        cma-default             Use upstream's default value


Name:   dht11
Info:   Overlay for the DHT11/DHT21/DHT22 humidity/temperature sensors
        Also sometimes found with the part number(s) AM230x.
Load:   dtoverlay=dht11,<param>=<val>
Params: gpiopin                 GPIO connected to the sensor's DATA output.
                                (default 4)


Name:   dionaudio-loco
Info:   Configures the Dion Audio LOCO DAC-AMP
Load:   dtoverlay=dionaudio-loco
Params: <None>


Name:   dionaudio-loco-v2
Info:   Configures the Dion Audio LOCO-V2 DAC-AMP
Load:   dtoverlay=dionaudio-loco-v2,<param>=<val>
Params: 24db_digital_gain       Allow gain to be applied via the PCM512x codec
                                Digital volume control. Enable with
                                "dtoverlay=hifiberry-dacplus,24db_digital_gain"
                                (The default behaviour is that the Digital
                                volume control is limited to a maximum of
                                0dB. ie. it can attenuate but not provide
                                gain. For most users, this will be desired
                                as it will prevent clipping. By appending
                                the 24dB_digital_gain parameter, the Digital
                                volume control will allow up to 24dB of
                                gain. If this parameter is enabled, it is the
                                responsibility of the user to ensure that
                                the Digital volume control is set to a value
                                that does not result in clipping/distortion!)


Name:   disable-bt
Info:   Disable onboard Bluetooth on Pi 3B, 3B+, 3A+, 4B and Zero W, restoring
        UART0/ttyAMA0 over GPIOs 14 & 15.
        N.B. To disable the systemd service that initialises the modem so it
        doesn't use the UART, use 'sudo systemctl disable hciuart'.
Load:   dtoverlay=disable-bt
Params: <None>


Name:   disable-wifi
Info:   Disable onboard WiFi on Pi 3B, 3B+, 3A+, 4B and Zero W.
Load:   dtoverlay=disable-wifi
Params: <None>


Name:   dpi18
Info:   Overlay for a generic 18-bit DPI display
        This uses GPIOs 0-21 (so no I2C, uart etc.), and activates the output
        2-3 seconds after the kernel has started.
Load:   dtoverlay=dpi18
Params: <None>


Name:   dpi24
Info:   Overlay for a generic 24-bit DPI display
        This uses GPIOs 0-27 (so no I2C, uart etc.), and activates the output
        2-3 seconds after the kernel has started.
Load:   dtoverlay=dpi24
Params: <None>


Name:   draws
Info:   Configures the NW Digital Radio DRAWS Hat

        The board includes an ADC to measure various board values and also
        provides two analog user inputs on the expansion header.  The ADC
        can be configured for various sample rates and gain values to adjust
        the input range.  Tables describing the two parameters follow.

        ADC Gain Values:
            0 = +/- 6.144V
            1 = +/- 4.096V
            2 = +/- 2.048V
            3 = +/- 1.024V
            4 = +/- 0.512V
            5 = +/- 0.256V
            6 = +/- 0.256V
            7 = +/- 0.256V

        ADC Datarate Values:
            0 = 128sps
            1 = 250sps
            2 = 490sps
            3 = 920sps
            4 = 1600sps (default)
            5 = 2400sps
            6 = 3300sps
            7 = 3300sps
Load:   dtoverlay=draws,<param>=<val>
Params: draws_adc_ch4_gain      Sets the full scale resolution of the ADCs
                                input voltage sensor (default 1)

        draws_adc_ch4_datarate  Sets the datarate of the ADCs input voltage
                                sensor

        draws_adc_ch5_gain      Sets the full scale resolution of the ADCs
                                5V rail voltage sensor (default 1)

        draws_adc_ch5_datarate  Sets the datarate of the ADCs 4V rail voltage
                                sensor

        draws_adc_ch6_gain      Sets the full scale resolution of the ADCs
                                AIN2 input (default 2)

        draws_adc_ch6_datarate  Sets the datarate of the ADCs AIN2 input

        draws_adc_ch7_gain      Sets the full scale resolution of the ADCs
                                AIN3 input (default 2)

        draws_adc_ch7_datarate  Sets the datarate of the ADCs AIN3 input

        alsaname                Name of the ALSA audio device (default "draws")


Name:   dwc-otg
Info:   Selects the dwc_otg USB controller driver which has fiq support. This
        is the default on all except the Pi Zero which defaults to dwc2.
Load:   dtoverlay=dwc-otg
Params: <None>


Name:   dwc2
Info:   Selects the dwc2 USB controller driver
Load:   dtoverlay=dwc2,<param>=<val>
Params: dr_mode                 Dual role mode: "host", "peripheral" or "otg"

        g-rx-fifo-size          Size of rx fifo size in gadget mode

        g-np-tx-fifo-size       Size of non-periodic tx fifo size in gadget
                                mode


[ The ds1307-rtc overlay has been deleted. See i2c-rtc. ]


Name:   enc28j60
Info:   Overlay for the Microchip ENC28J60 Ethernet Controller on SPI0
Load:   dtoverlay=enc28j60,<param>=<val>
Params: int_pin                 GPIO used for INT (default 25)

        speed                   SPI bus speed (default 12000000)


Name:   enc28j60-spi2
Info:   Overlay for the Microchip ENC28J60 Ethernet Controller on SPI2
Load:   dtoverlay=enc28j60-spi2,<param>=<val>
Params: int_pin                 GPIO used for INT (default 39)

        speed                   SPI bus speed (default 12000000)


Name:   exc3000
Info:   Enables I2C connected EETI EXC3000 multiple touch controller using
        GPIO 4 (pin 7 on GPIO header) for interrupt.
Load:   dtoverlay=exc3000,<param>=<val>
Params: interrupt               GPIO used for interrupt (default 4)
        sizex                   Touchscreen size x (default 4096)
        sizey                   Touchscreen size y (default 4096)
        invx                    Touchscreen inverted x axis
        invy                    Touchscreen inverted y axis
        swapxy                  Touchscreen swapped x y axis


Name:   fe-pi-audio
Info:   Configures the Fe-Pi Audio Sound Card
Load:   dtoverlay=fe-pi-audio
Params: <None>


Name:   goodix
Info:   Enables I2C connected Goodix gt9271 multiple touch controller using
        GPIOs 4 and 17 (pins 7 and 11 on GPIO header) for interrupt and reset.
Load:   dtoverlay=goodix,<param>=<val>
Params: interrupt               GPIO used for interrupt (default 4)
        reset                   GPIO used for reset (default 17)


Name:   googlevoicehat-soundcard
Info:   Configures the Google voiceHAT soundcard
Load:   dtoverlay=googlevoicehat-soundcard
Params: <None>


Name:   gpio-fan
Info:   Configure a GPIO pin to control a cooling fan.
Load:   dtoverlay=gpio-fan,<param>=<val>
Params: gpiopin                 GPIO used to control the fan (default 12)
        temp                    Temperature at which the fan switches on, in
                                millicelcius (default 55000)


Name:   gpio-ir
Info:   Use GPIO pin as rc-core style infrared receiver input. The rc-core-
        based gpio_ir_recv driver maps received keys directly to a
        /dev/input/event* device, all decoding is done by the kernel - LIRC is
        not required! The key mapping and other decoding parameters can be
        configured by "ir-keytable" tool.
Load:   dtoverlay=gpio-ir,<param>=<val>
Params: gpio_pin                Input pin number. Default is 18.

        gpio_pull               Desired pull-up/down state (off, down, up)
                                Default is "up".

        invert                  "1" = invert the input (active-low signalling).
                                "0" = non-inverted input (active-high
                                signalling). Default is "1".

        rc-map-name             Default rc keymap (can also be changed by
                                ir-keytable), defaults to "rc-rc6-mce"


Name:   gpio-ir-tx
Info:   Use GPIO pin as bit-banged infrared transmitter output.
        This is an alternative to "pwm-ir-tx". gpio-ir-tx doesn't require
        a PWM so it can be used together with onboard analog audio.
Load:   dtoverlay=gpio-ir-tx,<param>=<val>
Params: gpio_pin                Output GPIO (default 18)

        invert                  "1" = invert the output (make it active-low).
                                Default is "0" (active-high).


Name:   gpio-key
Info:   This is a generic overlay for activating GPIO keypresses using
        the gpio-keys library and this dtoverlay. Multiple keys can be
        set up using multiple calls to the overlay for configuring
        additional buttons or joysticks. You can see available keycodes
        at https://github.com/torvalds/linux/blob/v4.12/include/uapi/
        linux/input-event-codes.h#L64
Load:   dtoverlay=gpio-key,<param>=<val>
Params: gpio                    GPIO pin to trigger on (default 3)
        active_low              When this is 1 (active low), a falling
                                edge generates a key down event and a
                                rising edge generates a key up event.
                                When this is 0 (active high), this is
                                reversed. The default is 1 (active low)
        gpio_pull               Desired pull-up/down state (off, down, up)
                                Default is "up". Note that the default pin
                                (GPIO3) has an external pullup
        label                   Set a label for the key
        keycode                 Set the key code for the button


Name:   gpio-no-bank0-irq
Info:   Use this overlay to disable GPIO interrupts for GPIOs in bank 0 (0-27),
        which can be useful for UIO drivers.
        N.B. Using this overlay will trigger a kernel WARN during booting, but
        this can safely be ignored - the system should work as expected.
Load:   dtoverlay=gpio-no-bank0-irq
Params: <None>


Name:   gpio-no-irq
Info:   Use this overlay to disable all GPIO interrupts, which can be useful
        for user-space GPIO edge detection systems.
Load:   dtoverlay=gpio-no-irq
Params: <None>


Name:   gpio-poweroff
Info:   Drives a GPIO high or low on poweroff (including halt). Enabling this
        overlay will prevent the ability to boot by driving GPIO3 low.
Load:   dtoverlay=gpio-poweroff,<param>=<val>
Params: gpiopin                 GPIO for signalling (default 26)

        active_low              Set if the power control device requires a
                                high->low transition to trigger a power-down.
                                Note that this will require the support of a
                                custom dt-blob.bin to prevent a power-down
                                during the boot process, and that a reboot
                                will also cause the pin to go low.
        input                   Set if the gpio pin should be configured as
                                an input.
        export                  Set to export the configured pin to sysfs
        timeout_ms              Specify (in ms) how long the kernel waits for
                                power-down before issuing a WARN (default 3000).


Name:   gpio-shutdown
Info:   Initiates a shutdown when GPIO pin changes. The given GPIO pin
        is configured as an input key that generates KEY_POWER events.

        This event is handled by systemd-logind by initiating a
        shutdown. Systemd versions older than 225 need an udev rule
        enable listening to the input device:

                ACTION!="REMOVE", SUBSYSTEM=="input", KERNEL=="event*", \
                        SUBSYSTEMS=="platform", DRIVERS=="gpio-keys", \
                        ATTRS{keys}=="116", TAG+="power-switch"

        Alternatively this event can be handled also on systems without
        systemd, just by traditional SysV init daemon. KEY_POWER event
        (keycode 116) needs to be mapped to KeyboardSignal on console
        and then kb::kbrequest inittab action which is triggered by
        KeyboardSignal from console can be configured to issue system
        shutdown. Steps for this configuration are:

            Add following lines to the /etc/console-setup/remap.inc file:

                # Key Power as special keypress
                keycode 116 = KeyboardSignal

            Then add following lines to /etc/inittab file:

                # Action on special keypress (Key Power)
                kb::kbrequest:/sbin/shutdown -t1 -a -h -P now

            And finally reload configuration by calling following commands:

                # dpkg-reconfigure console-setup
                # service console-setup reload
                # init q

        This overlay only handles shutdown. After shutdown, the system
        can be powered up again by driving GPIO3 low. The default
        configuration uses GPIO3 with a pullup, so if you connect a
        button between GPIO3 and GND (pin 5 and 6 on the 40-pin header),
        you get a shutdown and power-up button. Please note that
        Raspberry Pi 1 Model B rev 1 uses GPIO1 instead of GPIO3.
Load:   dtoverlay=gpio-shutdown,<param>=<val>
Params: gpio_pin                GPIO pin to trigger on (default 3)
                                For Raspberry Pi 1 Model B rev 1 set this
                                explicitly to value 1, e.g.:

                                    dtoverlay=gpio-shutdown,gpio_pin=1

        active_low              When this is 1 (active low), a falling
                                edge generates a key down event and a
                                rising edge generates a key up event.
                                When this is 0 (active high), this is
                                reversed. The default is 1 (active low).

        gpio_pull               Desired pull-up/down state (off, down, up)
                                Default is "up".

                                Note that the default pin (GPIO3) has an
                                external pullup. Same applies for GPIO1
                                on Raspberry Pi 1 Model B rev 1.

        debounce                Specify the debounce interval in milliseconds
                                (default 100)


Name:   hd44780-lcd
Info:   Configures an HD44780 compatible LCD display. Uses 4 gpio pins for
        data, 2 gpio pins for enable and register select and 1 optional pin
        for enabling/disabling the backlight display.
Load:   dtoverlay=hd44780-lcd,<param>=<val>
Params: pin_d4                  GPIO pin for data pin D4 (default 6)

        pin_d5                  GPIO pin for data pin D5 (default 13)

        pin_d6                  GPIO pin for data pin D6 (default 19)

        pin_d7                  GPIO pin for data pin D7 (default 26)

        pin_en                  GPIO pin for "Enable" (default 21)

        pin_rs                  GPIO pin for "Register Select" (default 20)

        pin_bl                  Optional pin for enabling/disabling the
                                display backlight. (default disabled)

        display_height          Height of the display in characters

        display_width           Width of the display in characters


Name:   hdmi-backlight-hwhack-gpio
Info:   Devicetree overlay for GPIO based backlight on/off capability.
        Use this if you have one of those HDMI displays whose backlight cannot
        be controlled via DPMS over HDMI and plan to do a little soldering to
        use an RPi gpio pin for on/off switching. See:
        https://www.waveshare.com/wiki/7inch_HDMI_LCD_(C)#Backlight_Control
Load:   dtoverlay=hdmi-backlight-hwhack-gpio,<param>=<val>
Params: gpio_pin                GPIO pin used (default 17)
        active_low              Set this to 1 if the display backlight is
                                switched on when the wire goes low.
                                Leave the default (value 0) if the backlight
                                expects a high to switch it on.


Name:   hifiberry-amp
Info:   Configures the HifiBerry Amp and Amp+ audio cards
Load:   dtoverlay=hifiberry-amp
Params: <None>


Name:   hifiberry-dac
Info:   Configures the HifiBerry DAC audio card
Load:   dtoverlay=hifiberry-dac
Params: <None>


Name:   hifiberry-dacplus
Info:   Configures the HifiBerry DAC+ audio card
Load:   dtoverlay=hifiberry-dacplus,<param>=<val>
Params: 24db_digital_gain       Allow gain to be applied via the PCM512x codec
                                Digital volume control. Enable with
                                "dtoverlay=hifiberry-dacplus,24db_digital_gain"
                                (The default behaviour is that the Digital
                                volume control is limited to a maximum of
                                0dB. ie. it can attenuate but not provide
                                gain. For most users, this will be desired
                                as it will prevent clipping. By appending
                                the 24dB_digital_gain parameter, the Digital
                                volume control will allow up to 24dB of
                                gain. If this parameter is enabled, it is the
                                responsibility of the user to ensure that
                                the Digital volume control is set to a value
                                that does not result in clipping/distortion!)
        slave                   Force DAC+ Pro into slave mode, using Pi as
                                master for bit clock and frame clock.
        leds_off                If set to 'true' the onboard indicator LEDs
                                are switched off at all times.


Name:   hifiberry-dacplusadc
Info:   Configures the HifiBerry DAC+ADC audio card
Load:   dtoverlay=hifiberry-dacplusadc,<param>=<val>
Params: 24db_digital_gain       Allow gain to be applied via the PCM512x codec
                                Digital volume control. Enable with
                                "dtoverlay=hifiberry-dacplus,24db_digital_gain"
                                (The default behaviour is that the Digital
                                volume control is limited to a maximum of
                                0dB. ie. it can attenuate but not provide
                                gain. For most users, this will be desired
                                as it will prevent clipping. By appending
                                the 24dB_digital_gain parameter, the Digital
                                volume control will allow up to 24dB of
                                gain. If this parameter is enabled, it is the
                                responsibility of the user to ensure that
                                the Digital volume control is set to a value
                                that does not result in clipping/distortion!)
        slave                   Force DAC+ Pro into slave mode, using Pi as
                                master for bit clock and frame clock.
        leds_off                If set to 'true' the onboard indicator LEDs
                                are switched off at all times.


Name:   hifiberry-dacplusadcpro
Info:   Configures the HifiBerry DAC+ADC PRO audio card
Load:   dtoverlay=hifiberry-dacplusadcpro,<param>=<val>
Params: 24db_digital_gain       Allow gain to be applied via the PCM512x codec
                                Digital volume control. Enable with
                                "dtoverlay=hifiberry-dacplusadcpro,24db_digital_gain"
                                (The default behaviour is that the Digital
                                volume control is limited to a maximum of
                                0dB. ie. it can attenuate but not provide
                                gain. For most users, this will be desired
                                as it will prevent clipping. By appending
                                the 24dB_digital_gain parameter, the Digital
                                volume control will allow up to 24dB of
                                gain. If this parameter is enabled, it is the
                                responsibility of the user to ensure that
                                the Digital volume control is set to a value
                                that does not result in clipping/distortion!)
        slave                   Force DAC+ADC Pro into slave mode, using Pi as
                                master for bit clock and frame clock.
        leds_off                If set to 'true' the onboard indicator LEDs
                                are switched off at all times.


Name:   hifiberry-dacplusdsp
Info:   Configures the HifiBerry DAC+DSP audio card
Load:   dtoverlay=hifiberry-dacplusdsp
Params: <None>


Name:   hifiberry-dacplushd
Info:   Configures the HifiBerry DAC+ HD audio card
Load:   dtoverlay=hifiberry-dacplushd
Params: <None>


Name:   hifiberry-digi
Info:   Configures the HifiBerry Digi and Digi+ audio card
Load:   dtoverlay=hifiberry-digi
Params: <None>


Name:   hifiberry-digi-pro
Info:   Configures the HifiBerry Digi+ Pro audio card
Load:   dtoverlay=hifiberry-digi-pro
Params: <None>


Name:   highperi
Info:   Enables "High Peripheral" mode
Load:   dtoverlay=highperi
Params: <None>


Name:   hy28a
Info:   HY28A - 2.8" TFT LCD Display Module by HAOYU Electronics
        Default values match Texy's display shield
Load:   dtoverlay=hy28a,<param>=<val>
Params: speed                   Display SPI bus speed

        rotate                  Display rotation {0,90,180,270}

        fps                     Delay between frame updates

        debug                   Debug output level {0-7}

        xohms                   Touchpanel sensitivity (X-plate resistance)

        resetgpio               GPIO used to reset controller

        ledgpio                 GPIO used to control backlight


Name:   hy28b
Info:   HY28B - 2.8" TFT LCD Display Module by HAOYU Electronics
        Default values match Texy's display shield
Load:   dtoverlay=hy28b,<param>=<val>
Params: speed                   Display SPI bus speed

        rotate                  Display rotation {0,90,180,270}

        fps                     Delay between frame updates

        debug                   Debug output level {0-7}

        xohms                   Touchpanel sensitivity (X-plate resistance)

        resetgpio               GPIO used to reset controller

        ledgpio                 GPIO used to control backlight


Name:   hy28b-2017
Info:   HY28B 2017 version - 2.8" TFT LCD Display Module by HAOYU Electronics
        Default values match Texy's display shield
Load:   dtoverlay=hy28b-2017,<param>=<val>
Params: speed                   Display SPI bus speed

        rotate                  Display rotation {0,90,180,270}

        fps                     Delay between frame updates

        debug                   Debug output level {0-7}

        xohms                   Touchpanel sensitivity (X-plate resistance)

        resetgpio               GPIO used to reset controller

        ledgpio                 GPIO used to control backlight


Name:   i-sabre-q2m
Info:   Configures the Audiophonics I-SABRE Q2M DAC
Load:   dtoverlay=i-sabre-q2m
Params: <None>


Name:   i2c-bcm2708
Info:   Fall back to the i2c_bcm2708 driver for the i2c_arm bus.
Load:   dtoverlay=i2c-bcm2708
Params: <None>


Name:   i2c-gpio
Info:   Adds support for software i2c controller on gpio pins
Load:   dtoverlay=i2c-gpio,<param>=<val>
Params: i2c_gpio_sda            GPIO used for I2C data (default "23")

        i2c_gpio_scl            GPIO used for I2C clock (default "24")

        i2c_gpio_delay_us       Clock delay in microseconds
                                (default "2" = ~100kHz)

        bus                     Set to a unique, non-zero value if wanting
                                multiple i2c-gpio busses. If set, will be used
                                as the preferred bus number (/dev/i2c-<n>). If
                                not set, the default value is 0, but the bus
                                number will be dynamically assigned - probably
                                3.


Name:   i2c-mux
Info:   Adds support for a number of I2C bus multiplexers on i2c_arm
Load:   dtoverlay=i2c-mux,<param>=<val>
Params: pca9542                 Select the NXP PCA9542 device

        pca9545                 Select the NXP PCA9545 device

        pca9548                 Select the NXP PCA9548 device

        addr                    Change I2C address of the device (default 0x70)


[ The i2c-mux-pca9548a overlay has been deleted. See i2c-mux. ]


Name:   i2c-pwm-pca9685a
Info:   Adds support for an NXP PCA9685A I2C PWM controller on i2c_arm
Load:   dtoverlay=i2c-pwm-pca9685a,<param>=<val>
Params: addr                    I2C address of PCA9685A (default 0x40)


Name:   i2c-rtc
Info:   Adds support for a number of I2C Real Time Clock devices
Load:   dtoverlay=i2c-rtc,<param>=<val>
Params: abx80x                  Select one of the ABx80x family:
                                  AB0801, AB0803, AB0804, AB0805,
                                  AB1801, AB1803, AB1804, AB1805

        ds1307                  Select the DS1307 device

        ds1339                  Select the DS1339 device

        ds3231                  Select the DS3231 device

        m41t62                  Select the M41T62 device

        mcp7940x                Select the MCP7940x device

        mcp7941x                Select the MCP7941x device

        pcf2127                 Select the PCF2127 device

        pcf2129                 Select the PCF2129 device

        pcf8523                 Select the PCF8523 device

        pcf85363                Select the PCF85363 device

        pcf8563                 Select the PCF8563 device

        rv1805                  Select the Micro Crystal RV1805 device

        rv3028                  Select the Micro Crystal RV3028 device

        addr                    Sets the address for the RTC. Note that the
                                device must be configured to use the specified
                                address.

        trickle-diode-type      Diode type for trickle charge - "standard" or
                                "schottky" (ABx80x and RV1805 only)

        trickle-resistor-ohms   Resistor value for trickle charge (DS1339,
                                ABx80x, RV1805, RV3028)

        wakeup-source           Specify that the RTC can be used as a wakeup
                                source

        backup-switchover-mode  Backup power supply switch mode. Must be 0 for
                                off or 1 for Vdd < VBackup (RV3028 only)


Name:   i2c-rtc-gpio
Info:   Adds support for a number of I2C Real Time Clock devices
        using the software i2c controller
Load:   dtoverlay=i2c-rtc-gpio,<param>=<val>
Params: abx80x                  Select one of the ABx80x family:
                                  AB0801, AB0803, AB0804, AB0805,
                                  AB1801, AB1803, AB1804, AB1805

        ds1307                  Select the DS1307 device

        ds1339                  Select the DS1339 device

        ds3231                  Select the DS3231 device

        m41t62                  Select the M41T62 device

        mcp7940x                Select the MCP7940x device

        mcp7941x                Select the MCP7941x device

        pcf2127                 Select the PCF2127 device

        pcf2129                 Select the PCF2129 device

        pcf8523                 Select the PCF8523 device

        pcf8563                 Select the PCF8563 device

        rv1805                  Select the Micro Crystal RV1805 device

        rv3028                  Select the Micro Crystal RV3028 device

        addr                    Sets the address for the RTC. Note that the
                                device must be configured to use the specified
                                address.

        trickle-diode-type      Diode type for trickle charge - "standard" or
                                "schottky" (ABx80x and RV1805 only)

        trickle-resistor-ohms   Resistor value for trickle charge (DS1339,
                                ABx80x, RV1805, RV3028)

        wakeup-source           Specify that the RTC can be used as a wakeup
                                source

        backup-switchover-mode  Backup power supply switch mode. Must be 0 for
                                off or 1 for Vdd < VBackup (RV3028 only)

        i2c_gpio_sda            GPIO used for I2C data (default "23")

        i2c_gpio_scl            GPIO used for I2C clock (default "24")

        i2c_gpio_delay_us       Clock delay in microseconds
                                (default "2" = ~100kHz)


Name:   i2c-sensor
Info:   Adds support for a number of I2C barometric pressure and temperature
        sensors on i2c_arm
Load:   dtoverlay=i2c-sensor,<param>=<val>
Params: addr                    Set the address for the BME280, BME680, BMP280,
                                DS1621, HDC100X, LM75, SHT3x or TMP102

        bme280                  Select the Bosch Sensortronic BME280
                                Valid addresses 0x76-0x77, default 0x76

        bme680                  Select the Bosch Sensortronic BME680
                                Valid addresses 0x76-0x77, default 0x76

        bmp085                  Select the Bosch Sensortronic BMP085

        bmp180                  Select the Bosch Sensortronic BMP180

        bmp280                  Select the Bosch Sensortronic BMP280
                                Valid addresses 0x76-0x77, default 0x76

        ds1621                  Select the Dallas Semiconductors DS1621 temp
                                sensor. Valid addresses 0x48-0x4f, default 0x48

        hdc100x                 Select the Texas Instruments HDC100x temp sensor
                                Valid addresses 0x40-0x43, default 0x40

        htu21                   Select the HTU21 temperature and humidity sensor

        lm75                    Select the Maxim LM75 temperature sensor
                                Valid addresses 0x48-0x4f, default 0x4f

        lm75addr                Deprecated - use addr parameter instead

        max17040                Select the Maxim Integrated MAX17040 battery
                                monitor

        sht3x                   Select the Sensiron SHT3x temperature and
                                humidity sensor. Valid addresses 0x44-0x45,
                                default 0x44

        si7020                  Select the Silicon Labs Si7013/20/21 humidity/
                                temperature sensor

        sps30                   Select the Sensirion SPS30 particulate matter
                                sensor. Fixed address 0x69.

        tmp102                  Select the Texas Instruments TMP102 temp sensor
                                Valid addresses 0x48-0x4b, default 0x48

        tsl4531                 Select the AMS TSL4531 digital ambient light
                                sensor

        veml6070                Select the Vishay VEML6070 ultraviolet light
                                sensor


Name:   i2c0
Info:   Change i2c0 pin usage. Not all pin combinations are usable on all
        platforms - platforms other then Compute Modules can only use this
        to disable transaction combining.
Load:   dtoverlay=i2c0,<param>=<val>
Params: pins_0_1                Use pins 0 and 1 (default)
        pins_28_29              Use pins 28 and 29
        pins_44_45              Use pins 44 and 45
        pins_46_47              Use pins 46 and 47
        combine                 Allow transactions to be combined (default
                                "yes")


Name:   i2c0-bcm2708
Info:   Deprecated, legacy version of i2c0.
Load:   <Deprecated>


Name:   i2c1
Info:   Change i2c1 pin usage. Not all pin combinations are usable on all
        platforms - platforms other then Compute Modules can only use this
        to disable transaction combining.
Load:   dtoverlay=i2c1,<param>=<val>
Params: pins_2_3                Use pins 2 and 3 (default)
        pins_44_45              Use pins 44 and 45
        combine                 Allow transactions to be combined (default
                                "yes")


Name:   i2c1-bcm2708
Info:   Deprecated, legacy version of i2c1.
Load:   <Deprecated>


Name:   i2c3
Info:   Enable the i2c3 bus
Load:   dtoverlay=i2c3,<param>
Params: pins_2_3                Use GPIOs 2 and 3
        pins_4_5                Use GPIOs 4 and 5 (default)
        baudrate                Set the baudrate for the interface (default
                                "100000")


Name:   i2c4
Info:   Enable the i2c4 bus
Load:   dtoverlay=i2c4,<param>
Params: pins_6_7                Use GPIOs 6 and 7
        pins_8_9                Use GPIOs 8 and 9 (default)
        baudrate                Set the baudrate for the interface (default
                                "100000")


Name:   i2c5
Info:   Enable the i2c5 bus
Load:   dtoverlay=i2c5,<param>
Params: pins_10_11              Use GPIOs 10 and 11
        pins_12_13              Use GPIOs 12 and 13 (default)
        baudrate                Set the baudrate for the interface (default
                                "100000")


Name:   i2c6
Info:   Enable the i2c6 bus
Load:   dtoverlay=i2c6,<param>
Params: pins_0_1                Use GPIOs 0 and 1
        pins_22_23              Use GPIOs 22 and 23 (default)
        baudrate                Set the baudrate for the interface (default
                                "100000")


Name:   i2s-gpio28-31
Info:   move I2S function block to GPIO 28 to 31
Load:   dtoverlay=i2s-gpio28-31
Params: <None>


Name:   ilitek251x
Info:   Enables I2C connected Ilitek 251x multiple touch controller using
        GPIO 4 (pin 7 on GPIO header) for interrupt.
Load:   dtoverlay=ilitek251x,<param>=<val>
Params: interrupt               GPIO used for interrupt (default 4)
        sizex                   Touchscreen size x, horizontal resolution of
                                touchscreen (in pixels)
        sizey                   Touchscreen size y, vertical resolution of
                                touchscreen (in pixels)


Name:   imx219
Info:   Sony IMX219 camera module.
        Uses Unicam 1, which is the standard camera connector on most Pi
        variants.
Load:   dtoverlay=imx219
Params: <None>


Name:   imx477
Info:   Sony IMX477 camera module.
        Uses Unicam 1, which is the standard camera connector on most Pi
        variants.
Load:   dtoverlay=imx477
Params: <None>


Name:   iqaudio-codec
Info:   Configures the IQaudio Codec audio card
Load:   dtoverlay=iqaudio-codec
Params: <None>


Name:   iqaudio-dac
Info:   Configures the IQaudio DAC audio card
Load:   dtoverlay=iqaudio-dac,<param>
Params: 24db_digital_gain       Allow gain to be applied via the PCM512x codec
                                Digital volume control. Enable with
                                "dtoverlay=iqaudio-dac,24db_digital_gain"
                                (The default behaviour is that the Digital
                                volume control is limited to a maximum of
                                0dB. ie. it can attenuate but not provide
                                gain. For most users, this will be desired
                                as it will prevent clipping. By appending
                                the 24db_digital_gain parameter, the Digital
                                volume control will allow up to 24dB of
                                gain. If this parameter is enabled, it is the
                                responsibility of the user to ensure that
                                the Digital volume control is set to a value
                                that does not result in clipping/distortion!)


Name:   iqaudio-dacplus
Info:   Configures the IQaudio DAC+ audio card
Load:   dtoverlay=iqaudio-dacplus,<param>=<val>
Params: 24db_digital_gain       Allow gain to be applied via the PCM512x codec
                                Digital volume control. Enable with
                                "dtoverlay=iqaudio-dacplus,24db_digital_gain"
                                (The default behaviour is that the Digital
                                volume control is limited to a maximum of
                                0dB. ie. it can attenuate but not provide
                                gain. For most users, this will be desired
                                as it will prevent clipping. By appending
                                the 24db_digital_gain parameter, the Digital
                                volume control will allow up to 24dB of
                                gain. If this parameter is enabled, it is the
                                responsibility of the user to ensure that
                                the Digital volume control is set to a value
                                that does not result in clipping/distortion!)
        auto_mute_amp           If specified, unmute/mute the IQaudIO amp when
                                starting/stopping audio playback.
        unmute_amp              If specified, unmute the IQaudIO amp once when
                                the DAC driver module loads.


Name:   iqaudio-digi-wm8804-audio
Info:   Configures the IQAudIO Digi WM8804 audio card
Load:   dtoverlay=iqaudio-digi-wm8804-audio,<param>=<val>
Params: card_name               Override the default, "IQAudIODigi", card name.
        dai_name                Override the default, "IQAudIO Digi", dai name.
        dai_stream_name         Override the default, "IQAudIO Digi HiFi",
                                dai stream name.


Name:   irs1125
Info:   Infineon irs1125 TOF camera module.
        Uses Unicam 1, which is the standard camera connector on most Pi
        variants.
Load:   dtoverlay=irs1125
Params: <None>


Name:   jedec-spi-nor
Info:   Adds support for JEDEC-compliant SPI NOR flash devices.  (Note: The
        "jedec,spi-nor" kernel driver was formerly known as "m25p80".)
Load:   dtoverlay=jedec-spi-nor,<param>=<val>
Params: flash-spi<n>-<m>        Enables flash device on SPI<n>, CS#<m>.
        flash-fastr-spi<n>-<m>  Enables flash device with fast read capability
                                on SPI<n>, CS#<m>.


Name:   justboom-both
Info:   Simultaneous usage of an justboom-dac and justboom-digi based
        card
Load:   dtoverlay=justboom-both,<param>=<val>
Params: 24db_digital_gain       Allow gain to be applied via the PCM512x codec
                                Digital volume control. Enable with
                                "dtoverlay=justboom-dac,24db_digital_gain"
                                (The default behaviour is that the Digital
                                volume control is limited to a maximum of
                                0dB. ie. it can attenuate but not provide
                                gain. For most users, this will be desired
                                as it will prevent clipping. By appending
                                the 24dB_digital_gain parameter, the Digital
                                volume control will allow up to 24dB of
                                gain. If this parameter is enabled, it is the
                                responsibility of the user to ensure that
                                the Digital volume control is set to a value
                                that does not result in clipping/distortion!)


Name:   justboom-dac
Info:   Configures the JustBoom DAC HAT, Amp HAT, DAC Zero and Amp Zero audio
        cards
Load:   dtoverlay=justboom-dac,<param>=<val>
Params: 24db_digital_gain       Allow gain to be applied via the PCM512x codec
                                Digital volume control. Enable with
                                "dtoverlay=justboom-dac,24db_digital_gain"
                                (The default behaviour is that the Digital
                                volume control is limited to a maximum of
                                0dB. ie. it can attenuate but not provide
                                gain. For most users, this will be desired
                                as it will prevent clipping. By appending
                                the 24dB_digital_gain parameter, the Digital
                                volume control will allow up to 24dB of
                                gain. If this parameter is enabled, it is the
                                responsibility of the user to ensure that
                                the Digital volume control is set to a value
                                that does not result in clipping/distortion!)


Name:   justboom-digi
Info:   Configures the JustBoom Digi HAT and Digi Zero audio cards
Load:   dtoverlay=justboom-digi
Params: <None>


Name:   lirc-rpi
Info:   This overlay has been deprecated and removed - see gpio-ir
Load:   <Deprecated>


Name:   ltc294x
Info:   Adds support for the ltc294x family of battery gauges
Load:   dtoverlay=ltc294x,<param>=<val>
Params: ltc2941                 Select the ltc2941 device

        ltc2942                 Select the ltc2942 device

        ltc2943                 Select the ltc2943 device

        ltc2944                 Select the ltc2944 device

        resistor-sense          The sense resistor value in milli-ohms.
                                Can be a 32-bit negative value when the battery
                                has been connected to the wrong end of the
                                resistor.

        prescaler-exponent      Range and accuracy of the gauge. The value is
                                programmed into the chip only if it differs
                                from the current setting.
                                For LTC2941 only:
                                - Default value is 128
                                - the exponent is in the range 0-7 (default 7)
                                See the datasheet for more information.


Name:   max98357a
Info:   Configures the Maxim MAX98357A I2S DAC
Load:   dtoverlay=max98357a,<param>=<val>
Params: no-sdmode               Driver does not manage the state of the DAC's
                                SD_MODE pin (i.e. chip is always on).
        sdmode-pin              integer, GPIO pin connected to the SD_MODE input
                                of the DAC (default GPIO4 if parameter omitted).


Name:   mbed-dac
Info:   Configures the mbed AudioCODEC (TLV320AIC23B)
Load:   dtoverlay=mbed-dac
Params: <None>


Name:   mcp23017
Info:   Configures the MCP23017 I2C GPIO expander
Load:   dtoverlay=mcp23017,<param>=<val>
Params: gpiopin                 Gpio pin connected to the INTA output of the
                                MCP23017 (default: 4)

        addr                    I2C address of the MCP23017 (default: 0x20)

        mcp23008                Configure an MCP23008 instead.
        noints                  Disable the interrupt GPIO line.


Name:   mcp23s17
Info:   Configures the MCP23S08/17 SPI GPIO expanders.
        If devices are present on SPI1 or SPI2, those interfaces must be enabled
        with one of the spi1-1/2/3cs and/or spi2-1/2/3cs overlays.
        If interrupts are enabled for a device on a given CS# on a SPI bus, that
        device must be the only one present on that SPI bus/CS#.
Load:   dtoverlay=mcp23s17,<param>=<val>
Params: s08-spi<n>-<m>-present  4-bit integer, bitmap indicating MCP23S08
                                devices present on SPI<n>, CS#<m>

        s17-spi<n>-<m>-present  8-bit integer, bitmap indicating MCP23S17
                                devices present on SPI<n>, CS#<m>

        s08-spi<n>-<m>-int-gpio integer, enables interrupts on a single
                                MCP23S08 device on SPI<n>, CS#<m>, specifies
                                the GPIO pin to which INT output of MCP23S08
                                is connected.

        s17-spi<n>-<m>-int-gpio integer, enables mirrored interrupts on a
                                single MCP23S17 device on SPI<n>, CS#<m>,
                                specifies the GPIO pin to which either INTA
                                or INTB output of MCP23S17 is connected.


Name:   mcp2515-can0
Info:   Configures the MCP2515 CAN controller on spi0.0
Load:   dtoverlay=mcp2515-can0,<param>=<val>
Params: oscillator              Clock frequency for the CAN controller (Hz)

        spimaxfrequency         Maximum SPI frequence (Hz)

        interrupt               GPIO for interrupt signal


Name:   mcp2515-can1
Info:   Configures the MCP2515 CAN controller on spi0.1
Load:   dtoverlay=mcp2515-can1,<param>=<val>
Params: oscillator              Clock frequency for the CAN controller (Hz)

        spimaxfrequency         Maximum SPI frequence (Hz)

        interrupt               GPIO for interrupt signal


Name:   mcp3008
Info:   Configures MCP3008 A/D converters
        For devices on spi1 or spi2, the interfaces should be enabled
        with one of the spi1-1/2/3cs and/or spi2-1/2/3cs overlays.
Load:   dtoverlay=mcp3008,<param>[=<val>]
Params: spi<n>-<m>-present      boolean, configure device at spi<n>, cs<m>
        spi<n>-<m>-speed        integer, set the spi bus speed for this device


Name:   mcp3202
Info:   Configures MCP3202 A/D converters
        For devices on spi1 or spi2, the interfaces should be enabled
        with one of the spi1-1/2/3cs and/or spi2-1/2/3cs overlays.
Load:   dtoverlay=mcp3202,<param>[=<val>]
Params: spi<n>-<m>-present      boolean, configure device at spi<n>, cs<m>
        spi<n>-<m>-speed        integer, set the spi bus speed for this device


Name:   mcp342x
Info:   Overlay for activation of Microchip MCP3421-3428 ADCs over I2C
Load:   dtoverlay=mcp342x,<param>=<val>
Params: addr                    I2C bus address of device, for devices with
                                addresses that are configurable, e.g. by
                                hardware links (default=0x68)
        mcp3421                 The device is an MCP3421
        mcp3422                 The device is an MCP3422
        mcp3423                 The device is an MCP3423
        mcp3424                 The device is an MCP3424
        mcp3425                 The device is an MCP3425
        mcp3426                 The device is an MCP3426
        mcp3427                 The device is an MCP3427
        mcp3428                 The device is an MCP3428


Name:   media-center
Info:   Media Center HAT - 2.83" Touch Display + extras by Pi Supply
Load:   dtoverlay=media-center,<param>=<val>
Params: speed                   Display SPI bus speed
        rotate                  Display rotation {0,90,180,270}
        fps                     Delay between frame updates
        xohms                   Touchpanel sensitivity (X-plate resistance)
        swapxy                  Swap x and y axis
        backlight               Change backlight GPIO pin {e.g. 12, 18}
        gpio_out_pin            GPIO for output (default "17")
        gpio_in_pin             GPIO for input (default "18")
        gpio_in_pull            Pull up/down/off on the input pin
                                (default "down")
        sense                   Override the IR receive auto-detection logic:
                                 "0" = force active-high
                                 "1" = force active-low
                                 "-1" = use auto-detection
                                (default "-1")
        softcarrier             Turn the software carrier "on" or "off"
                                (default "on")
        invert                  "on" = invert the output pin (default "off")
        debug                   "on" = enable additional debug messages
                                (default "off")


Name:   merus-amp
Info:   Configures the merus-amp audio card
Load:   dtoverlay=merus-amp
Params: <None>


Name:   midi-uart0
Info:   Configures UART0 (ttyAMA0) so that a requested 38.4kbaud actually gets
        31.25kbaud, the frequency required for MIDI
Load:   dtoverlay=midi-uart0
Params: <None>


Name:   midi-uart1
Info:   Configures UART1 (ttyS0) so that a requested 38.4kbaud actually gets
        31.25kbaud, the frequency required for MIDI
Load:   dtoverlay=midi-uart1
Params: <None>


Name:   miniuart-bt
Info:   Switch the onboard Bluetooth function on Pi 3B, 3B+, 3A+, 4B and Zero W
        to use the mini-UART (ttyS0) and restore UART0/ttyAMA0 over GPIOs 14 &
        15. Note that this may reduce the maximum usable baudrate.
        N.B. It is also necessary to edit /lib/systemd/system/hciuart.service
        and replace ttyAMA0 with ttyS0, unless using Raspbian or another
        distribution with udev rules that create /dev/serial0 and /dev/serial1,
        in which case use /dev/serial1 instead because it will always be
        correct. Furthermore, you must also set core_freq and core_freq_min to
        the same value in config.txt or the miniuart will not work.
Load:   dtoverlay=miniuart-bt
Params: <None>


Name:   mmc
Info:   Selects the bcm2835-mmc SD/MMC driver, optionally with overclock
Load:   dtoverlay=mmc,<param>=<val>
Params: overclock_50            Clock (in MHz) to use when the MMC framework
                                requests 50MHz


Name:   mpu6050
Info:   Overlay for i2c connected mpu6050 imu
Load:   dtoverlay=mpu6050,<param>=<val>
Params: interrupt               GPIO pin for interrupt (default 4)


Name:   mz61581
Info:   MZ61581 display by Tontec
Load:   dtoverlay=mz61581,<param>=<val>
Params: speed                   Display SPI bus speed

        rotate                  Display rotation {0,90,180,270}

        fps                     Delay between frame updates

        txbuflen                Transmit buffer length (default 32768)

        debug                   Debug output level {0-7}

        xohms                   Touchpanel sensitivity (X-plate resistance)


Name:   ov5647
Info:   Omnivision OV5647 camera module.
        Uses Unicam 1, which is the standard camera connector on most Pi
        variants.
Load:   dtoverlay=ov5647
Params: <None>


Name:   papirus
Info:   PaPiRus ePaper Screen by Pi Supply (both HAT and pHAT)
Load:   dtoverlay=papirus,<param>=<val>
Params: panel                   Display panel (required):
                                1.44": e1144cs021
                                2.0":  e2200cs021
                                2.7":  e2271cs021

        speed                   Display SPI bus speed


[ The pcf2127-rtc overlay has been deleted. See i2c-rtc. ]


[ The pcf8523-rtc overlay has been deleted. See i2c-rtc. ]


[ The pcf8563-rtc overlay has been deleted. See i2c-rtc. ]


Name:   pi3-act-led
Info:   This overlay has been renamed act-led, keeping pi3-act-led as an alias
        for backwards compatibility.
Load:   <Deprecated>


Name:   pi3-disable-bt
Info:   This overlay has been renamed disable-bt, keeping pi3-disable-bt as an
        alias for backwards compatibility.
Load:   <Deprecated>


Name:   pi3-disable-wifi
Info:   This overlay has been renamed disable-wifi, keeping pi3-disable-wifi as
        an alias for backwards compatibility.
Load:   <Deprecated>


Name:   pi3-miniuart-bt
Info:   This overlay has been renamed miniuart-bt, keeping pi3-miniuart-bt as
        an alias for backwards compatibility.
Load:   <Deprecated>


Name:   pibell
Info:   Configures the pibell audio card.
Load:   dtoverlay=pibell,<param>=<val>
Params: alsaname                Set the name as it appears in ALSA (default
                                "PiBell")


Name:   piglow
Info:   Configures the PiGlow by pimoroni.com
Load:   dtoverlay=piglow
Params: <None>


Name:   piscreen
Info:   PiScreen display by OzzMaker.com
Load:   dtoverlay=piscreen,<param>=<val>
Params: speed                   Display SPI bus speed

        rotate                  Display rotation {0,90,180,270}

        fps                     Delay between frame updates

        debug                   Debug output level {0-7}

        xohms                   Touchpanel sensitivity (X-plate resistance)


Name:   piscreen2r
Info:   PiScreen 2 with resistive TP display by OzzMaker.com
Load:   dtoverlay=piscreen2r,<param>=<val>
Params: speed                   Display SPI bus speed

        rotate                  Display rotation {0,90,180,270}

        fps                     Delay between frame updates

        debug                   Debug output level {0-7}

        xohms                   Touchpanel sensitivity (X-plate resistance)


Name:   pisound
Info:   Configures the Blokas Labs pisound card
Load:   dtoverlay=pisound
Params: <None>


Name:   pitft22
Info:   Adafruit PiTFT 2.2" screen
Load:   dtoverlay=pitft22,<param>=<val>
Params: speed                   Display SPI bus speed

        rotate                  Display rotation {0,90,180,270}

        fps                     Delay between frame updates

        debug                   Debug output level {0-7}


Name:   pitft28-capacitive
Info:   Adafruit PiTFT 2.8" capacitive touch screen
Load:   dtoverlay=pitft28-capacitive,<param>=<val>
Params: speed                   Display SPI bus speed

        rotate                  Display rotation {0,90,180,270}

        fps                     Delay between frame updates

        debug                   Debug output level {0-7}

        touch-sizex             Touchscreen size x (default 240)

        touch-sizey             Touchscreen size y (default 320)

        touch-invx              Touchscreen inverted x axis

        touch-invy              Touchscreen inverted y axis

        touch-swapxy            Touchscreen swapped x y axis


Name:   pitft28-resistive
Info:   Adafruit PiTFT 2.8" resistive touch screen
Load:   dtoverlay=pitft28-resistive,<param>=<val>
Params: speed                   Display SPI bus speed

        rotate                  Display rotation {0,90,180,270}

        fps                     Delay between frame updates

        debug                   Debug output level {0-7}


Name:   pitft35-resistive
Info:   Adafruit PiTFT 3.5" resistive touch screen
Load:   dtoverlay=pitft35-resistive,<param>=<val>
Params: speed                   Display SPI bus speed

        rotate                  Display rotation {0,90,180,270}

        fps                     Delay between frame updates

        debug                   Debug output level {0-7}


Name:   pps-gpio
Info:   Configures the pps-gpio (pulse-per-second time signal via GPIO).
Load:   dtoverlay=pps-gpio,<param>=<val>
Params: gpiopin                 Input GPIO (default "18")
        assert_falling_edge     When present, assert is indicated by a falling
                                edge, rather than by a rising edge (default
                                off)
        capture_clear           Generate clear events on the trailing edge
                                (default off)


Name:   pwm
Info:   Configures a single PWM channel
        Legal pin,function combinations for each channel:
          PWM0: 12,4(Alt0) 18,2(Alt5) 40,4(Alt0)            52,5(Alt1)
          PWM1: 13,4(Alt0) 19,2(Alt5) 41,4(Alt0) 45,4(Alt0) 53,5(Alt1)
        N.B.:
          1) Pin 18 is the only one available on all platforms, and
             it is the one used by the I2S audio interface.
             Pins 12 and 13 might be better choices on an A+, B+ or Pi2.
          2) The onboard analogue audio output uses both PWM channels.
          3) So be careful mixing audio and PWM.
          4) Currently the clock must have been enabled and configured
             by other means.
Load:   dtoverlay=pwm,<param>=<val>
Params: pin                     Output pin (default 18) - see table
        func                    Pin function (default 2 = Alt5) - see above
        clock                   PWM clock frequency (informational)


Name:   pwm-2chan
Info:   Configures both PWM channels
        Legal pin,function combinations for each channel:
          PWM0: 12,4(Alt0) 18,2(Alt5) 40,4(Alt0)            52,5(Alt1)
          PWM1: 13,4(Alt0) 19,2(Alt5) 41,4(Alt0) 45,4(Alt0) 53,5(Alt1)
        N.B.:
          1) Pin 18 is the only one available on all platforms, and
             it is the one used by the I2S audio interface.
             Pins 12 and 13 might be better choices on an A+, B+ or Pi2.
          2) The onboard analogue audio output uses both PWM channels.
          3) So be careful mixing audio and PWM.
          4) Currently the clock must have been enabled and configured
             by other means.
Load:   dtoverlay=pwm-2chan,<param>=<val>
Params: pin                     Output pin (default 18) - see table
        pin2                    Output pin for other channel (default 19)
        func                    Pin function (default 2 = Alt5) - see above
        func2                   Function for pin2 (default 2 = Alt5)
        clock                   PWM clock frequency (informational)


Name:   pwm-ir-tx
Info:   Use GPIO pin as pwm-assisted infrared transmitter output.
        This is an alternative to "gpio-ir-tx". pwm-ir-tx makes use
        of PWM0 to reduce the CPU load during transmission compared to
        gpio-ir-tx which uses bit-banging.
        Legal pin,function combinations are:
          12,4(Alt0) 18,2(Alt5) 40,4(Alt0) 52,5(Alt1)
Load:   dtoverlay=pwm-ir-tx,<param>=<val>
Params: gpio_pin                Output GPIO (default 18)

        func                    Pin function (default 2 = Alt5)


Name:   qca7000
Info:   I2SE's Evaluation Board for PLC Stamp micro
Load:   dtoverlay=qca7000,<param>=<val>
Params: int_pin                 GPIO pin for interrupt signal (default 23)

        speed                   SPI bus speed (default 12 MHz)


Name:   rotary-encoder
Info:   Overlay for GPIO connected rotary encoder.
Load:   dtoverlay=rotary-encoder,<param>=<val>
Params: pin_a                   GPIO connected to rotary encoder channel A
                                (default 4).
        pin_b                   GPIO connected to rotary encoder channel B
                                (default 17).
        relative_axis           register a relative axis rather than an
                                absolute one. Relative axis will only
                                generate +1/-1 events on the input device,
                                hence no steps need to be passed.
        linux_axis              the input subsystem axis to map to this
                                rotary encoder. Defaults to 0 (ABS_X / REL_X)
        rollover                Automatic rollover when the rotary value
                                becomes greater than the specified steps or
                                smaller than 0. For absolute axis only.
        steps-per-period        Number of steps (stable states) per period.
                                The values have the following meaning:
                                1: Full-period mode (default)
                                2: Half-period mode
                                4: Quarter-period mode
        steps                   Number of steps in a full turnaround of the
                                encoder. Only relevant for absolute axis.
                                Defaults to 24 which is a typical value for
                                such devices.
        wakeup                  Boolean, rotary encoder can wake up the
                                system.
        encoding                String, the method used to encode steps.
                                Supported are "gray" (the default and more
                                common) and "binary".


Name:   rpi-backlight
Info:   Raspberry Pi official display backlight driver
Load:   dtoverlay=rpi-backlight
Params: <None>


Name:   rpi-cirrus-wm5102
Info:   Configures the Cirrus Logic Audio Card
Load:   dtoverlay=rpi-cirrus-wm5102
Params: <None>


Name:   rpi-dac
Info:   Configures the RPi DAC audio card
Load:   dtoverlay=rpi-dac
Params: <None>


Name:   rpi-display
Info:   RPi-Display - 2.8" Touch Display by Watterott
Load:   dtoverlay=rpi-display,<param>=<val>
Params: speed                   Display SPI bus speed
        rotate                  Display rotation {0,90,180,270}
        fps                     Delay between frame updates
        debug                   Debug output level {0-7}
        xohms                   Touchpanel sensitivity (X-plate resistance)
        swapxy                  Swap x and y axis
        backlight               Change backlight GPIO pin {e.g. 12, 18}


Name:   rpi-ft5406
Info:   Official Raspberry Pi display touchscreen
Load:   dtoverlay=rpi-ft5406,<param>=<val>
Params: touchscreen-size-x      Touchscreen X resolution (default 800)
        touchscreen-size-y      Touchscreen Y resolution (default 600);
        touchscreen-inverted-x  Invert touchscreen X coordinates (default 0);
        touchscreen-inverted-y  Invert touchscreen Y coordinates (default 0);
        touchscreen-swapped-x-y Swap X and Y cordinates (default 0);


Name:   rpi-poe
Info:   Raspberry Pi PoE HAT fan
Load:   dtoverlay=rpi-poe,<param>[=<val>]
Params: poe_fan_temp0           Temperature (in millicelcius) at which the fan
                                turns on (default 40000)
        poe_fan_temp0_hyst      Temperature delta (in millicelcius) at which
                                the fan turns off (default 2000)
        poe_fan_temp1           Temperature (in millicelcius) at which the fan
                                speeds up (default 45000)
        poe_fan_temp1_hyst      Temperature delta (in millicelcius) at which
                                the fan slows down (default 2000)
        poe_fan_temp2           Temperature (in millicelcius) at which the fan
                                speeds up (default 50000)
        poe_fan_temp2_hyst      Temperature delta (in millicelcius) at which
                                the fan slows down (default 2000)
        poe_fan_temp3           Temperature (in millicelcius) at which the fan
                                speeds up (default 55000)
        poe_fan_temp3_hyst      Temperature delta (in millicelcius) at which
                                the fan slows down (default 5000)


Name:   rpi-proto
Info:   Configures the RPi Proto audio card
Load:   dtoverlay=rpi-proto
Params: <None>


Name:   rpi-sense
Info:   Raspberry Pi Sense HAT
Load:   dtoverlay=rpi-sense
Params: <None>


Name:   rpi-tv
Info:   Raspberry Pi TV HAT
Load:   dtoverlay=rpi-tv
Params: <None>


Name:   rpivid-v4l2
Info:   Load the V4L2 stateless video decoder driver for the HEVC block,
        disabling the memory mapped devices in the process.
Load:   dtoverlay=rpivid-v4l2
Params: <None>


Name:   rra-digidac1-wm8741-audio
Info:   Configures the Red Rocks Audio DigiDAC1 soundcard
Load:   dtoverlay=rra-digidac1-wm8741-audio
Params: <None>


Name:   sc16is750-i2c
Info:   Overlay for the NXP SC16IS750 UART with I2C Interface
        Enables the chip on I2C1 at 0x48 (or the "addr" parameter value). To
        select another address, please refer to table 10 in reference manual.
Load:   dtoverlay=sc16is750-i2c,<param>=<val>
Params: int_pin                 GPIO used for IRQ (default 24)
        addr                    Address (default 0x48)
        xtal                    On-board crystal frequency (default 14745600)


Name:   sc16is752-i2c
Info:   Overlay for the NXP SC16IS752 dual UART with I2C Interface
        Enables the chip on I2C1 at 0x48 (or the "addr" parameter value). To
        select another address, please refer to table 10 in reference manual.
Load:   dtoverlay=sc16is752-i2c,<param>=<val>
Params: int_pin                 GPIO used for IRQ (default 24)
        addr                    Address (default 0x48)
        xtal                    On-board crystal frequency (default 14745600)


Name:   sc16is752-spi0
Info:   Overlay for the NXP SC16IS752 Dual UART with SPI Interface
        Enables the chip on SPI0.
Load:   dtoverlay=sc16is752-spi0,<param>=<val>
Params: int_pin                 GPIO used for IRQ (default 24)
        xtal                    On-board crystal frequency (default 14745600)


Name:   sc16is752-spi1
Info:   Overlay for the NXP SC16IS752 Dual UART with SPI Interface
        Enables the chip on SPI1.
        N.B.: spi1 is only accessible on devices with a 40pin header, eg:
              A+, B+, Zero and PI2 B; as well as the Compute Module.

Load:   dtoverlay=sc16is752-spi1,<param>=<val>
Params: int_pin                 GPIO used for IRQ (default 24)
        xtal                    On-board crystal frequency (default 14745600)


Name:   sdhost
Info:   Selects the bcm2835-sdhost SD/MMC driver, optionally with overclock.
        N.B. This overlay is designed for situations where the mmc driver is
        the default, so it disables the other (mmc) interface - this will kill
        WiFi on a Pi3. If this isn't what you want, either use the sdtweak
        overlay or the new sd_* dtparams of the base DTBs.
Load:   dtoverlay=sdhost,<param>=<val>
Params: overclock_50            Clock (in MHz) to use when the MMC framework
                                requests 50MHz

        force_pio               Disable DMA support (default off)

        pio_limit               Number of blocks above which to use DMA
                                (default 1)

        debug                   Enable debug output (default off)


Name:   sdio
Info:   Selects the bcm2835-sdhost SD/MMC driver, optionally with overclock,
        and enables SDIO via GPIOs 22-27. An example of use in 1-bit mode is
        "dtoverlay=sdio,bus_width=1,gpios_22_25"
Load:   dtoverlay=sdio,<param>=<val>
Params: sdio_overclock          SDIO Clock (in MHz) to use when the MMC
                                framework requests 50MHz

        poll_once               Disable SDIO-device polling every second
                                (default on: polling once at boot-time)

        bus_width               Set the SDIO host bus width (default 4 bits)

        gpios_22_25             Select GPIOs 22-25 for 1-bit mode. Must be used
                                with bus_width=1. This replaces the sdio-1bit
                                overlay, which is now deprecated.

        gpios_34_37             Select GPIOs 34-37 for 1-bit mode. Must be used
                                with bus_width=1.

        gpios_34_39             Select GPIOs 34-39 for 4-bit mode. Must be used
                                with bus_width=4 (the default).


Name:   sdio-1bit
Info:   This overlay is now deprecated. Use
        "dtoverlay=sdio,bus_width=1,gpios_22_25" instead.
Load:   <Deprecated>


Name:   sdtweak
Info:   Tunes the bcm2835-sdhost SD/MMC driver
        N.B. This functionality is now available via the sd_* dtparams in the
        base DTB.
Load:   dtoverlay=sdtweak,<param>=<val>
Params: overclock_50            Clock (in MHz) to use when the MMC framework
                                requests 50MHz

        force_pio               Disable DMA support (default off)

        pio_limit               Number of blocks above which to use DMA
                                (default 1)

        debug                   Enable debug output (default off)

        poll_once               Looks for a card once after booting. Useful
                                for network booting scenarios to avoid the
                                overhead of continuous polling. N.B. Using
                                this option restricts the system to using a
                                single card per boot (or none at all).
                                (default off)

        enable                  Set to off to completely disable the interface
                                (default on)


Name:   sh1106-spi
Info:   Overlay for SH1106 OLED via SPI using fbtft staging driver.
Load:   dtoverlay=sh1106-spi,<param>=<val>
Params: speed                   SPI bus speed (default 4000000)
        rotate                  Display rotation (0, 90, 180 or 270; default 0)
        fps                     Delay between frame updates (default 25)
        debug                   Debug output level (0-7; default 0)
        dc_pin                  GPIO pin for D/C (default 24)
        reset_pin               GPIO pin for RESET (default 25)
        height                  Display height (32 or 64; default 64)


Name:   smi
Info:   Enables the Secondary Memory Interface peripheral. Uses GPIOs 2-25!
Load:   dtoverlay=smi
Params: <None>


Name:   smi-dev
Info:   Enables the userspace interface for the SMI driver
Load:   dtoverlay=smi-dev
Params: <None>


Name:   smi-nand
Info:   Enables access to NAND flash via the SMI interface
Load:   dtoverlay=smi-nand
Params: <None>


Name:   spi-gpio35-39
Info:   Move SPI function block to GPIO 35 to 39
Load:   dtoverlay=spi-gpio35-39
Params: <None>


Name:   spi-gpio40-45
Info:   Move SPI function block to GPIOs 40 to 45
Load:   dtoverlay=spi-gpio40-45
Params: <None>


Name:   spi-rtc
Info:   Adds support for a number of SPI Real Time Clock devices
Load:   dtoverlay=spi-rtc,<param>=<val>
Params: pcf2123                 Select the PCF2123 device


Name:   spi0-cs
Info:   Allows the (software) CS pins for SPI0 to be changed
Load:   dtoverlay=spi0-cs,<param>=<val>
Params: cs0_pin                 GPIO pin for CS0 (default 8)
        cs1_pin                 GPIO pin for CS1 (default 7)


Name:   spi0-hw-cs
Info:   Re-enables hardware CS/CE (chip selects) for SPI0
Load:   dtoverlay=spi0-hw-cs
Params: <None>


Name:   spi1-1cs
Info:   Enables spi1 with a single chip select (CS) line and associated spidev
        dev node. The gpio pin number for the CS line and spidev device node
        creation are configurable.
        N.B.: spi1 is only accessible on devices with a 40pin header, eg:
              A+, B+, Zero and PI2 B; as well as the Compute Module.
Load:   dtoverlay=spi1-1cs,<param>=<val>
Params: cs0_pin                 GPIO pin for CS0 (default 18 - BCM SPI1_CE0).
        cs0_spidev              Set to 'disabled' to stop the creation of a
                                userspace device node /dev/spidev1.0 (default
                                is 'okay' or enabled).


Name:   spi1-2cs
Info:   Enables spi1 with two chip select (CS) lines and associated spidev
        dev nodes. The gpio pin numbers for the CS lines and spidev device node
        creation are configurable.
        N.B.: spi1 is only accessible on devices with a 40pin header, eg:
              A+, B+, Zero and PI2 B; as well as the Compute Module.
Load:   dtoverlay=spi1-2cs,<param>=<val>
Params: cs0_pin                 GPIO pin for CS0 (default 18 - BCM SPI1_CE0).
        cs1_pin                 GPIO pin for CS1 (default 17 - BCM SPI1_CE1).
        cs0_spidev              Set to 'disabled' to stop the creation of a
                                userspace device node /dev/spidev1.0 (default
                                is 'okay' or enabled).
        cs1_spidev              Set to 'disabled' to stop the creation of a
                                userspace device node /dev/spidev1.1 (default
                                is 'okay' or enabled).


Name:   spi1-3cs
Info:   Enables spi1 with three chip select (CS) lines and associated spidev
        dev nodes. The gpio pin numbers for the CS lines and spidev device node
        creation are configurable.
        N.B.: spi1 is only accessible on devices with a 40pin header, eg:
              A+, B+, Zero and PI2 B; as well as the Compute Module.
Load:   dtoverlay=spi1-3cs,<param>=<val>
Params: cs0_pin                 GPIO pin for CS0 (default 18 - BCM SPI1_CE0).
        cs1_pin                 GPIO pin for CS1 (default 17 - BCM SPI1_CE1).
        cs2_pin                 GPIO pin for CS2 (default 16 - BCM SPI1_CE2).
        cs0_spidev              Set to 'disabled' to stop the creation of a
                                userspace device node /dev/spidev1.0 (default
                                is 'okay' or enabled).
        cs1_spidev              Set to 'disabled' to stop the creation of a
                                userspace device node /dev/spidev1.1 (default
                                is 'okay' or enabled).
        cs2_spidev              Set to 'disabled' to stop the creation of a
                                userspace device node /dev/spidev1.2 (default
                                is 'okay' or enabled).


Name:   spi2-1cs
Info:   Enables spi2 with a single chip select (CS) line and associated spidev
        dev node. The gpio pin number for the CS line and spidev device node
        creation are configurable.
        N.B.: spi2 is only accessible with the Compute Module.
Load:   dtoverlay=spi2-1cs,<param>=<val>
Params: cs0_pin                 GPIO pin for CS0 (default 43 - BCM SPI2_CE0).
        cs0_spidev              Set to 'disabled' to stop the creation of a
                                userspace device node /dev/spidev2.0 (default
                                is 'okay' or enabled).


Name:   spi2-2cs
Info:   Enables spi2 with two chip select (CS) lines and associated spidev
        dev nodes. The gpio pin numbers for the CS lines and spidev device node
        creation are configurable.
        N.B.: spi2 is only accessible with the Compute Module.
Load:   dtoverlay=spi2-2cs,<param>=<val>
Params: cs0_pin                 GPIO pin for CS0 (default 43 - BCM SPI2_CE0).
        cs1_pin                 GPIO pin for CS1 (default 44 - BCM SPI2_CE1).
        cs0_spidev              Set to 'disabled' to stop the creation of a
                                userspace device node /dev/spidev2.0 (default
                                is 'okay' or enabled).
        cs1_spidev              Set to 'disabled' to stop the creation of a
                                userspace device node /dev/spidev2.1 (default
                                is 'okay' or enabled).


Name:   spi2-3cs
Info:   Enables spi2 with three chip select (CS) lines and associated spidev
        dev nodes. The gpio pin numbers for the CS lines and spidev device node
        creation are configurable.
        N.B.: spi2 is only accessible with the Compute Module.
Load:   dtoverlay=spi2-3cs,<param>=<val>
Params: cs0_pin                 GPIO pin for CS0 (default 43 - BCM SPI2_CE0).
        cs1_pin                 GPIO pin for CS1 (default 44 - BCM SPI2_CE1).
        cs2_pin                 GPIO pin for CS2 (default 45 - BCM SPI2_CE2).
        cs0_spidev              Set to 'disabled' to stop the creation of a
                                userspace device node /dev/spidev2.0 (default
                                is 'okay' or enabled).
        cs1_spidev              Set to 'disabled' to stop the creation of a
                                userspace device node /dev/spidev2.1 (default
                                is 'okay' or enabled).
        cs2_spidev              Set to 'disabled' to stop the creation of a
                                userspace device node /dev/spidev2.2 (default
                                is 'okay' or enabled).


Name:   spi3-1cs
Info:   Enables spi3 with a single chip select (CS) line and associated spidev
        dev node. The gpio pin number for the CS line and spidev device node
        creation are configurable.
Load:   dtoverlay=spi3-1cs,<param>=<val>
Params: cs0_pin                 GPIO pin for CS0 (default 0 - BCM SPI3_CE0).
        cs0_spidev              Set to 'off' to prevent the creation of a
                                userspace device node /dev/spidev3.0 (default
                                is 'on' or enabled).


Name:   spi3-2cs
Info:   Enables spi3 with two chip select (CS) lines and associated spidev
        dev nodes. The gpio pin numbers for the CS lines and spidev device node
        creation are configurable.
Load:   dtoverlay=spi3-2cs,<param>=<val>
Params: cs0_pin                 GPIO pin for CS0 (default 0 - BCM SPI3_CE0).
        cs1_pin                 GPIO pin for CS1 (default 24 - BCM SPI3_CE1).
        cs0_spidev              Set to 'off' to prevent the creation of a
                                userspace device node /dev/spidev3.0 (default
                                is 'on' or enabled).
        cs1_spidev              Set to 'off' to prevent the creation of a
                                userspace device node /dev/spidev3.1 (default
                                is 'on' or enabled).


Name:   spi4-1cs
Info:   Enables spi4 with a single chip select (CS) line and associated spidev
        dev node. The gpio pin number for the CS line and spidev device node
        creation are configurable.
Load:   dtoverlay=spi4-1cs,<param>=<val>
Params: cs0_pin                 GPIO pin for CS0 (default 4 - BCM SPI4_CE0).
        cs0_spidev              Set to 'off' to prevent the creation of a
                                userspace device node /dev/spidev4.0 (default
                                is 'on' or enabled).


Name:   spi4-2cs
Info:   Enables spi4 with two chip select (CS) lines and associated spidev
        dev nodes. The gpio pin numbers for the CS lines and spidev device node
        creation are configurable.
Load:   dtoverlay=spi4-2cs,<param>=<val>
Params: cs0_pin                 GPIO pin for CS0 (default 4 - BCM SPI4_CE0).
        cs1_pin                 GPIO pin for CS1 (default 25 - BCM SPI4_CE1).
        cs0_spidev              Set to 'off' to prevent the creation of a
                                userspace device node /dev/spidev4.0 (default
                                is 'on' or enabled).
        cs1_spidev              Set to 'off' to prevent the creation of a
                                userspace device node /dev/spidev4.1 (default
                                is 'on' or enabled).


Name:   spi5-1cs
Info:   Enables spi5 with a single chip select (CS) line and associated spidev
        dev node. The gpio pin numbers for the CS lines and spidev device node
        creation are configurable.
Load:   dtoverlay=spi5-1cs,<param>=<val>
Params: cs0_pin                 GPIO pin for CS0 (default 12 - BCM SPI5_CE0).
        cs0_spidev              Set to 'off' to prevent the creation of a
                                userspace device node /dev/spidev5.0 (default
                                is 'on' or enabled).


Name:   spi5-2cs
Info:   Enables spi5 with two chip select (CS) lines and associated spidev
        dev nodes. The gpio pin numbers for the CS lines and spidev device node
        creation are configurable.
Load:   dtoverlay=spi5-2cs,<param>=<val>
Params: cs0_pin                 GPIO pin for CS0 (default 12 - BCM SPI5_CE0).
        cs1_pin                 GPIO pin for CS1 (default 26 - BCM SPI5_CE1).
        cs0_spidev              Set to 'off' to prevent the creation of a
                                userspace device node /dev/spidev5.0 (default
                                is 'on' or enabled).
        cs1_spidev              Set to 'off' to prevent the creation of a
                                userspace device node /dev/spidev5.1 (default
                                is 'on' or enabled).


Name:   spi6-1cs
Info:   Enables spi6 with a single chip select (CS) line and associated spidev
        dev node. The gpio pin number for the CS line and spidev device node
        creation are configurable.
Load:   dtoverlay=spi6-1cs,<param>=<val>
Params: cs0_pin                 GPIO pin for CS0 (default 18 - BCM SPI6_CE0).
        cs0_spidev              Set to 'off' to prevent the creation of a
                                userspace device node /dev/spidev6.0 (default
                                is 'on' or enabled).


Name:   spi6-2cs
Info:   Enables spi6 with two chip select (CS) lines and associated spidev
        dev nodes. The gpio pin numbers for the CS lines and spidev device node
        creation are configurable.
Load:   dtoverlay=spi6-2cs,<param>=<val>
Params: cs0_pin                 GPIO pin for CS0 (default 18 - BCM SPI6_CE0).
        cs1_pin                 GPIO pin for CS1 (default 27 - BCM SPI6_CE1).
        cs0_spidev              Set to 'off' to prevent the creation of a
                                userspace device node /dev/spidev6.0 (default
                                is 'on' or enabled).
        cs1_spidev              Set to 'off' to prevent the creation of a
                                userspace device node /dev/spidev6.1 (default
                                is 'on' or enabled).


Name:   ssd1306
Info:   Overlay for activation of SSD1306 over I2C OLED display framebuffer.
Load:   dtoverlay=ssd1306,<param>=<val>
Params: address                 Location in display memory of first character.
                                (default=0)
        width                   Width of display. (default=128)
        height                  Height of display. (default=64)
        offset                  virtual channel a. (default=0)
        normal                  Has no effect on displays tested. (default=not
                                set)
        sequential              Set this if every other scan line is missing.
                                (default=not set)
        remapped                Set this if display is garbled. (default=not
                                set)
        inverted                Set this if display is inverted and mirrored.
                                (default=not set)

        Examples:
        Typical usage for 128x64 display: dtoverlay=ssd1306,inverted

        Typical usage for 128x32 display: dtoverlay=ssd1306,inverted,sequential

        i2c_baudrate=400000 will speed up the display.

        i2c_baudrate=1000000 seems to work even though it's not officially
        supported by the hardware, and is faster still.

        For more information refer to the device datasheet at:
        https://cdn-shop.adafruit.com/datasheets/SSD1306.pdf


Name:   ssd1306-spi
Info:   Overlay for SSD1306 OLED via SPI using fbtft staging driver.
Load:   dtoverlay=ssd1306-spi,<param>=<val>
Params: speed                   SPI bus speed (default 10000000)
        rotate                  Display rotation (0, 90, 180 or 270; default 0)
        fps                     Delay between frame updates (default 25)
        debug                   Debug output level (0-7; default 0)
        dc_pin                  GPIO pin for D/C (default 24)
        reset_pin               GPIO pin for RESET (default 25)
        height                  Display height (32 or 64; default 64)


Name:   ssd1351-spi
Info:   Overlay for SSD1351 OLED via SPI using fbtft staging driver.
Load:   dtoverlay=ssd1351-spi,<param>=<val>
Params: speed                   SPI bus speed (default 4500000)
        rotate                  Display rotation (0, 90, 180 or 270; default 0)
        fps                     Delay between frame updates (default 25)
        debug                   Debug output level (0-7; default 0)
        dc_pin                  GPIO pin for D/C (default 24)
        reset_pin               GPIO pin for RESET (default 25)


Name:   superaudioboard
Info:   Configures the SuperAudioBoard sound card
Load:   dtoverlay=superaudioboard,<param>=<val>
Params: gpiopin                 GPIO pin for codec reset


Name:   sx150x
Info:   Configures the Semtech SX150X I2C GPIO expanders.
Load:   dtoverlay=sx150x,<param>=<val>
Params: sx150<x>-<n>-<m>        Enables SX150X device on I2C#<n> with slave
                                address <m>. <x> may be 1-9. <n> may be 0 or 1.
                                Permissible values of <m> (which is denoted in
                                hex) depend on the device variant. For SX1501,
                                SX1502, SX1504 and SX1505, <m> may be 20 or 21.
                                For SX1503 and SX1506, <m> may be 20. For
                                SX1507 and SX1509, <m> may be 3E, 3F, 70 or 71.
                                For SX1508, <m> may be 20, 21, 22 or 23.

        sx150<x>-<n>-<m>-int-gpio
                                Integer, enables interrupts on SX150X device on
                                I2C#<n> with slave address <m>, specifies
                                the GPIO pin to which NINT output of SX150X is
                                connected.


Name:   tc358743
Info:   Toshiba TC358743 HDMI to CSI-2 bridge chip.
        Uses Unicam 1, which is the standard camera connector on most Pi
        variants.
Load:   dtoverlay=tc358743,<param>=<val>
Params: 4lane                   Use 4 lanes (only applicable to Compute Modules
                                CAM1 connector).

        link-frequency          Set the link frequency. Only values of 297000000
                                (574Mbit/s) and 486000000 (972Mbit/s - default)
                                are supported by the driver.


Name:   tc358743-audio
Info:   Used in combination with the tc358743-fast overlay to route the audio
        from the TC358743 over I2S to the Pi.
        Wiring is LRCK/WFS to GPIO 19, BCK/SCK to GPIO 18, and DATA/SD to GPIO
        20.
Load:   dtoverlay=tc358743-audio,<param>=<val>
Params: card-name               Override the default, "tc358743", card name.


Name:   tinylcd35
Info:   3.5" Color TFT Display by www.tinylcd.com
        Options: Touch, RTC, keypad
Load:   dtoverlay=tinylcd35,<param>=<val>
Params: speed                   Display SPI bus speed

        rotate                  Display rotation {0,90,180,270}

        fps                     Delay between frame updates

        debug                   Debug output level {0-7}

        touch                   Enable touch panel

        touchgpio               Touch controller IRQ GPIO

        xohms                   Touchpanel: Resistance of X-plate in ohms

        rtc-pcf                 PCF8563 Real Time Clock

        rtc-ds                  DS1307 Real Time Clock

        keypad                  Enable keypad

        Examples:
            Display with touchpanel, PCF8563 RTC and keypad:
                dtoverlay=tinylcd35,touch,rtc-pcf,keypad
            Old touch display:
                dtoverlay=tinylcd35,touch,touchgpio=3


Name:   tpm-slb9670
Info:   Enables support for Infineon SLB9670 Trusted Platform Module add-on
        boards, which can be used as a secure key storage and hwrng,
        available as "Iridium SLB9670" by Infineon and "LetsTrust TPM" by pi3g.
Load:   dtoverlay=tpm-slb9670
Params: <None>


Name:   uart0
Info:   Change the pin usage of uart0
Load:   dtoverlay=uart0,<param>=<val>
Params: txd0_pin                GPIO pin for TXD0 (14, 32 or 36 - default 14)

        rxd0_pin                GPIO pin for RXD0 (15, 33 or 37 - default 15)

        pin_func                Alternative pin function - 4(Alt0) for 14&15,
                                7(Alt3) for 32&33, 6(Alt2) for 36&37


Name:   uart1
Info:   Change the pin usage of uart1
Load:   dtoverlay=uart1,<param>=<val>
Params: txd1_pin                GPIO pin for TXD1 (14, 32 or 40 - default 14)

        rxd1_pin                GPIO pin for RXD1 (15, 33 or 41 - default 15)


Name:   uart2
Info:   Enable uart 2 on GPIOs 0-3
Load:   dtoverlay=uart2,<param>
Params: ctsrts                  Enable CTS/RTS on GPIOs 2-3 (default off)


Name:   uart3
Info:   Enable uart 3 on GPIOs 4-7
Load:   dtoverlay=uart3,<param>
Params: ctsrts                  Enable CTS/RTS on GPIOs 6-7 (default off)


Name:   uart4
Info:   Enable uart 4 on GPIOs 8-11
Load:   dtoverlay=uart4,<param>
Params: ctsrts                  Enable CTS/RTS on GPIOs 10-11 (default off)


Name:   uart5
Info:   Enable uart 5 on GPIOs 12-15
Load:   dtoverlay=uart5,<param>
Params: ctsrts                  Enable CTS/RTS on GPIOs 14-15 (default off)


Name:   udrc
Info:   Configures the NW Digital Radio UDRC Hat
Load:   dtoverlay=udrc,<param>=<val>
Params: alsaname                Name of the ALSA audio device (default "udrc")


Name:   upstream
Info:   Allow usage of downstream .dtb with upstream kernel. Comprises the
        vc4-kms-v3d and dwc2 overlays.
Load:   dtoverlay=upstream
Params: <None>


Name:   upstream-aux-interrupt
Info:   This overlay has been deprecated and removed because it is no longer
        necessary.
Load:   <Deprecated>


Name:   upstream-pi4
Info:   Allow usage of downstream .dtb with upstream kernel on Pi 4. Comprises
        the vc4-kms-v3d-pi4 and dwc2 overlays.
Load:   dtoverlay=upstream-pi4
Params: <None>


Name:   vc4-fkms-v3d
Info:   Enable Eric Anholt's DRM VC4 V3D driver on top of the dispmanx
        display stack.
Load:   dtoverlay=vc4-fkms-v3d,<param>
Params: cma-256                 CMA is 256MB (needs 1GB)
        cma-192                 CMA is 192MB (needs 1GB)
        cma-128                 CMA is 128MB
        cma-96                  CMA is 96MB
        cma-64                  CMA is 64MB
        cma-size                CMA size in bytes, 4MB aligned
        cma-default             Use upstream's default value


Name:   vc4-kms-kippah-7inch
Info:   Enable the Adafruit DPI Kippah with the 7" Ontat panel attached.
        Requires vc4-kms-v3d to be loaded.
Load:   dtoverlay=vc4-kms-kippah-7inch
Params: <None>


Name:   vc4-kms-v3d
Info:   Enable Eric Anholt's DRM VC4 HDMI/HVS/V3D driver.
Load:   dtoverlay=vc4-kms-v3d,<param>
Params: cma-256                 CMA is 256MB (needs 1GB)
        cma-192                 CMA is 192MB (needs 1GB)
        cma-128                 CMA is 128MB
        cma-96                  CMA is 96MB
        cma-64                  CMA is 64MB
        cma-size                CMA size in bytes, 4MB aligned
        cma-default             Use upstream's default value
        audio                   Enable or disable audio over HDMI (default "on")


Name:   vc4-kms-v3d-pi4
Info:   Enable Eric Anholt's DRM VC4 HDMI/HVS/V3D driver for Pi4.
Load:   dtoverlay=vc4-kms-v3d-pi4,<param>
Params: cma-256                 CMA is 256MB
        cma-192                 CMA is 192MB
        cma-128                 CMA is 128MB
        cma-96                  CMA is 96MB
        cma-64                  CMA is 64MB
        cma-size                CMA size in bytes, 4MB aligned
        cma-default             Use upstream's default value
        audio                   Enable or disable audio over HDMI0 (default
                                "on")
        audio1                  Enable or disable audio over HDMI1 (default
                                "on")


Name:   vga666
Info:   Overlay for the Fen Logic VGA666 board
        This uses GPIOs 2-21 (so no I2C), and activates the output 2-3 seconds
        after the kernel has started.
Load:   dtoverlay=vga666
Params: <None>


Name:   w1-gpio
Info:   Configures the w1-gpio Onewire interface module.
        Use this overlay if you *don't* need a GPIO to drive an external pullup.
Load:   dtoverlay=w1-gpio,<param>=<val>
Params: gpiopin                 GPIO for I/O (default "4")
        pullup                  Now enabled by default (ignored)


Name:   w1-gpio-pullup
Info:   Configures the w1-gpio Onewire interface module.
        Use this overlay if you *do* need a GPIO to drive an external pullup.
Load:   dtoverlay=w1-gpio-pullup,<param>=<val>
Params: gpiopin                 GPIO for I/O (default "4")
        extpullup               GPIO for external pullup (default "5")
        pullup                  Now enabled by default (ignored)


Name:   w5500
Info:   Overlay for the Wiznet W5500 Ethernet Controller on SPI0
Load:   dtoverlay=w5500,<param>=<val>
Params: int_pin                 GPIO used for INT (default 25)

        speed                   SPI bus speed (default 30000000)

        cs                      SPI bus Chip Select (default 0)


Name:   wittypi
Info:   Configures the wittypi RTC module.
Load:   dtoverlay=wittypi,<param>=<val>
Params: led_gpio                GPIO for LED (default "17")
        led_trigger             Choose which activity the LED tracks (default
                                "default-on")


Troubleshooting
===============

If you are experiencing problems that you think are DT-related, enable DT
diagnostic output by adding this to /boot/config.txt:

    dtdebug=on

and rebooting. Then run:

    sudo vcdbg log msg

and look for relevant messages.

Further reading
===============

This is only meant to be a quick introduction to the subject of Device Tree on
Raspberry Pi. There is a more complete explanation here:

http://www.raspberrypi.org/documentation/configuration/device-tree.md
